local Run=game:GetService("RunService")
local UIS=game:GetService("UserInputService")
local Players=game:GetService("Players")
local package=script.Parent.Parent
local C=require(script.Parent.PredictionConfig)
local Codec=require(script.Parent.PredictionCheckpoint)
local Predictor=require(script.Parent.LocalPrediction)
local Simulation=require(script.Parent.PredictionSimulation)
local Render=require(script.Parent.RenderPresentation)
local Snap=require(script.Parent.RenderSnapshot)
local Tune=require(package.Core.TestTune)
local Driver=require(script.Parent.DriverConfig)
local M={};M.__index=M
function M.new(primary,presentation,keys,showTelemetry)
    local self=setmetatable({player=Players.LocalPlayer,entries={},connections={},keys=keys,showTelemetry=showTelemetry,
        control=package:WaitForChild("PredictionControl"),state=package:WaitForChild("PredictionState"),
        sendTimer=0,telemetryTimer=0,primary=primary},M)
    self.entries[primary]={car=primary,presentation=presentation}
    local world=primary.Parent
    local function add(car)
        if self.closed or self.entries[car] or not car:IsA("Model") or not car:FindFirstChild("DriverSeat") or not car:FindFirstChild("Chassis") then return end
        local pres=Render.new(car,require(package.Core.CupTune).new(),package.RenderState)
        self.entries[car]={car=car,presentation=pres}
        local f=package:FindFirstChild("CarModel")
        if f and f:FindFirstChild("NR2003CarModelClient") then
            local model=require(f.NR2003CarModelClient).new(car,pres,package,self.player,keys)
            self:bindModel(car,model)
        end
    end
    for _,car in ipairs(world:GetChildren()) do add(car) end
    local function deferAdd(car) if task then task.defer(add,car) else add(car) end end
    self.connections[#self.connections+1]=world.ChildAdded:Connect(deferAdd)
    if world.DescendantAdded then self.connections[#self.connections+1]=world.DescendantAdded:Connect(function(child)
        if child.Name=="DriverSeat" or child.Name=="Chassis" then deferAdd(child.Parent) end
    end) end
    self.connections[#self.connections+1]=self.control.OnClientEvent:Connect(function(msg)
        local ok,err=pcall(function() self:receive(msg) end)
        if not ok then self.fault=tostring(err);warn("Stage 14 local: "..self.fault) end
    end)
    self.connections[#self.connections+1]=self.state.OnClientEvent:Connect(function(msg)
        if type(msg)~="table" then return end
        for _,e in pairs(self.entries) do
            if e.car:GetAttribute("PredictionVehicleId")==msg.id then
                if e.predictor then return end -- local pose/cockpit never passes through remote buffers
                if e.epoch and msg.epoch<e.epoch then return end
                if e.epoch~=msg.epoch then e.presentation.buffer= require(script.Parent.SnapshotBuffer).new(require(script.Parent.RenderConfig).buffer) end
                e.epoch=msg.epoch
                local snap=Snap.decode(msg.snapshot)
                if snap then e.presentation.buffer:push(snap,workspace:GetServerTimeNow());e.lastRemote=snap.time end
                if e.model and msg.draw then
                    local ds=e.drawModule.decode(msg.draw);if ds then e.model.buf:push(ds) end
                end
            end
        end
    end)
    -- Ready is sent after listeners exist; server records it even before seat ownership.
    self.control:FireServer({kind="ready"})
    if task then task.defer(function()
        local e=self.entries[primary]
        if not self.closed and e and not e.sim and not e.warm then
            e.warm=Simulation.new(primary,Tune.new(),nil,true,function() return self.player end,false)
        end
    end) end
    return self
end
function M:bindModel(car,model)
    local e=self.entries[car];if not e then return end
    e.model=model
    local f=package:FindFirstChild("CarModel")
    e.drawModule=f and require(f.NR2003DrawState)
    if model then model.stage14=true end
end
function M:stop(e,discard)
    e.pendingAck=nil
    if e.predictor then e.predictor=nil;e.presentation.localPredictor=nil end
    if e.sim then e.warm=e.sim;e.sim=nil end
    if discard and e.warm then e.warm:destroy();e.warm=nil end
    if e.model then e.model.localDrawState=nil end
    e.offset=nil
end
function M:receive(msg)
    if type(msg)~="table" then return end
    local e=self.entries[msg.car]
    if not e then for _,candidate in pairs(self.entries) do
        if candidate.car:GetAttribute("PredictionVehicleId")==msg.id then e=candidate;break end
    end end
    if not e then return end
    if msg.kind=="start" then
        if e.epoch and msg.epoch<=e.epoch and e.predictor then return end
        if e.epoch and msg.epoch<e.epoch then return end
        local h=self.player.Character and self.player.Character:FindFirstChildOfClass("Humanoid")
        if not h or h.SeatPart~=e.car.DriverSeat then e.pendingStart=msg;return end
        self:stop(e);e.epoch=msg.epoch
        -- Preparation can be costly; it happens once per ownership/reset, never per command.
        e.sim=e.warm or Simulation.new(e.car,Tune.new(),nil,true,function() return self.player end,false)
        e.warm=nil
        e.predictor=Predictor.new(e.sim,e.epoch,Codec.unpack(msg.checkpoint))
        e.presentation.localPredictor=e.predictor;e.sim:present()
        self.pendingShift=0;self.fault=nil
    elseif msg.kind=="stop" and msg.epoch==e.epoch then
        e.pendingStart=nil;self:stop(e)
    elseif msg.kind=="pong" and e.predictor and msg.epoch==e.epoch and type(msg.echo)=="number" then
        e.predictor.rtt=math.max(0,os.clock()-msg.echo)
    elseif msg.kind=="ack" and e.predictor and msg.epoch==e.epoch then
        -- Verification can finish a held 8-tick command before the local host reaches
        -- its end. Keep its correction until that tick exists locally.
        if type(msg.tick)~="number" then return end
        if msg.tick>e.sim:tick() then
            if not e.pendingAck or msg.checkpoint or not e.pendingAck.checkpoint then e.pendingAck=msg end
            return
        end
        if e.pendingAck and e.pendingAck.checkpoint and not msg.checkpoint and msg.ack>e.pendingAck.ack then return end
        local before=e.sim.adapter.rootCF
        local count=e.predictor.reconciliations
        e.predictor:acknowledge(msg,os.clock())
        if e.predictor.reconciliations~=count then
            local after=e.sim.adapter.rootCF
            local distance=(before.Position-after.Position).Magnitude*e.sim.adapter.tune.metresPerStud
            if distance<C.snapMetres then e.offset=before*after:Inverse();e.offsetAge=0 else e.offset=nil end
        end
        e.divergence=msg.divergence;e.rejected=msg.rejected
    end
end
function M:shift(delta) self.pendingShift=delta end
function M:noteInput() self.inputEvent=os.clock() end
function M:sample()
    local k=self.keys();local axis,analog=0,false
    local last=UIS:GetLastInputType()
    if last.Name:sub(1,7)=="Gamepad" and UIS:GetGamepadConnected(last) then
        for _,obj in ipairs(UIS:GetGamepadState(last)) do
            if obj.KeyCode==Enum.KeyCode.Thumbstick1 then
                axis=obj.Position.X
                if math.abs(axis)<(Driver.gamepadSteerDeadzone or 0) then axis=0 end
                analog=true
            end
        end
    end
    local shift=self.pendingShift or 0;self.pendingShift=0
    local left,right=k.Left and 1 or 0,k.Right and 1 or 0
    if self.inputEvent then self.sampleEvent=self.inputEvent;self.inputEvent=nil end
    return {throttle=k.Gas and 1 or 0,brake=k.Brake and 1 or 0,clutch=k.Clutch and 1 or 0,
        handbrake=k.Handbrake and 1 or 0,steer=analog and axis or right-left,
        steerLeft=left,steerRight=right,steerAxis=axis,steerAnalog=analog,shift=shift}
end
function M:frame(dt)
    local humanoid=self.player.Character and self.player.Character:FindFirstChildOfClass("Humanoid")
    local seat=humanoid and humanoid.SeatPart
    local focus
    for car,e in pairs(self.entries) do
        if not car.Parent then self:stop(e,true);e.presentation:destroy();if e.model then e.model:destroy() end;self.entries[car]=nil;continue end
        local driving=seat==car:FindFirstChild("DriverSeat")
        if driving then focus=e end
        if driving and e.pendingStart then local start=e.pendingStart;e.pendingStart=nil;self:receive(start) end
        if e.predictor and not driving then self:stop(e) end
        if e.predictor and driving then
            local ok,err=pcall(function()
                e.predictor:advance(dt,function() return self:sample() end,math.max(C.clientBudget,math.min(0.025,dt*0.5)))
                if e.pendingAck and e.pendingAck.tick<=e.sim:tick() then
                    local ack=e.pendingAck;e.pendingAck=nil;self:receive(ack)
                end
                e.sim:present()
                if e.offset then
                    e.offsetAge+=dt
                    local alpha=math.clamp(e.offsetAge/C.smoothSeconds,0,1)
                    car:PivotTo(e.offset:Lerp(CFrame.identity,alpha)*e.sim.adapter.rootCF)
                    if alpha==1 then e.offset=nil end
                end
                if self.sampleEvent then
                    self.eventToPresent=os.clock()-self.sampleEvent;self.sampleEvent=nil
                end
                if e.model and e.drawModule then
                    e.model.localDrawState=e.drawModule.sample(e.sim.adapter.core,{}, {})
                end
            end)
            if not ok then self.fault=tostring(err);warn(self.fault);self:stop(e) end
        end
        if e~=focus then
            e.presentation:update();if e.model then e.model:update(dt,false) end
        end
    end
    self.focus=focus;self.sendTimer+=dt;self.telemetryTimer+=dt
    if focus and not focus.predictor then
        self.readyTimer=(self.readyTimer or 0)+dt
        if self.readyTimer>=1 then self.readyTimer=0;self.control:FireServer({kind="ready"}) end
    else self.readyTimer=0 end
    if focus and focus.predictor then
        self.pingTimer=(self.pingTimer or 0)+dt
        if self.pingTimer>=1 then
            self.pingTimer=0;self.control:FireServer({kind="ping",id=focus.car:GetAttribute("PredictionVehicleId"),epoch=focus.epoch,echo=os.clock()})
        end
        if self.sendTimer>=1/C.sendHz then
            self.sendTimer=0
            local msg=focus.predictor:packet(os.clock());msg.id=focus.car:GetAttribute("PredictionVehicleId")
            self.control:FireServer(msg)
            local stats=focus.predictor:stats()
            if stats.unacknowledged>=C.historyFrames-8 or stats.hardResyncs>(focus.lastHardResync or 0) then
                focus.lastHardResync=stats.hardResyncs
                self.control:FireServer({kind="resync",id=msg.id,epoch=msg.epoch})
            end
        end
        if self.telemetryTimer>=0.1 then
            self.telemetryTimer=0;self.showTelemetry(focus.sim.adapter:telemetry())
        end
    end
    return focus
end
function M:stats()
    local e=self.focus
    if e and e.predictor then
        local s=e.predictor:stats();s.mode="LOCAL NR2003";s.eventToPresent=self.eventToPresent
        s.divergence=e.divergence;s.fault=self.fault;return s
    end
    return {mode=self.fault or "waiting for driver/initial state",tick=0,ack=0,ackTick=0,unacknowledged=0,
        rtt=0,backlog=0,reconciliations=0,correction=0,remoteAge=e and e.lastRemote and workspace:GetServerTimeNow()-e.lastRemote}
end
function M:destroy()
    self.closed=true
    for _,c in ipairs(self.connections) do c:Disconnect() end
    for _,e in pairs(self.entries) do self:stop(e,true);e.presentation:destroy();if e.model then e.model:destroy() end end
    self.entries={}
end
return M
