-- The SAME V6 adapter/core on both hosts. No transform is used as simulation input.
local Adapter=require(script.Parent.CupChassisAdapter)
local Codec=require(script.Parent.PredictionCheckpoint)
local M={};M.__index=M
local fields={"origin","inContact","planes","pendingShift","controlsSuspended","weather","trackNormal",
    "draftTest","rootCF","collision","appliedSetupKey","brakeBias","originalTrack",
    "appliedTrackSetupName","appliedTrackSetupSHA256","requestedTrackSetupName","requestedTrackSetupSHA256"}
function M.new(car,tune,remote,client,driver,prepareSpawn)
    local a=Adapter.new(car,tune,remote,{client=client,networked=true,driver=driver,prepareSpawn=prepareSpawn})
    assert(a.originalTrack,"Stage 14 requires installed V6 native track contacts")
    return setmetatable({adapter=a},M)
end
function M:tick() return self.adapter.core:tick() end
function M:step(input) self.adapter:tickCore(input) end
function M:shift(delta) self.adapter:shift(delta) end
function M:state() return self.adapter.core:readState() end
function M:checkpoint()
    local a=self.adapter;local c=a.core:checkpoint();c.adapter={}
    for _,key in ipairs(fields) do c.adapter[key]=Codec.copy(a[key]) end
    return c
end
function M:restore(c)
    assert(c.schema==14 and c.adapter and c.hosts,"Stage 14 requires a complete checkpoint")
    local a=self.adapter;a.core:restore(c)
    for _,key in ipairs(fields) do a[key]=Codec.copy(c.adapter[key]) end
    a.stepper.state.tick=a.core:tick();a.runner.accumulator=0
    -- rootCF comes from that checkpoint, never from the currently rendered car.
end
function M:present() self.adapter:present() end
function M:destroy() self.adapter:destroy() end
return M
