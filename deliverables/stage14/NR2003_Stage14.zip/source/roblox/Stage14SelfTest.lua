local P=require(script.Parent.PredictionProtocol)
local Codec=require(script.Parent.PredictionCheckpoint)
local Session=require(script.Parent.PredictionSession)
local M={}
function M.run()
    assert(P.input({steer=0/0})==nil,"nonfinite input")
    assert(P.input({throttle=2})==nil,"input range")
    assert(P.command({seq=2,tick=0,input={}},0)==nil,"tick sequence")
    local memory=buffer.create(4096);buffer.writeu32(memory,2048,123456)
    local packed=Codec.pack({memory=memory,tick=8})
    assert(buffer.tostring(Codec.unpack(packed).memory)==buffer.tostring(memory),"checkpoint round trip")
    local sim={t=0}
    function sim:tick() return self.t end
    function sim:state() return table.create(45,0) end
    function sim:shift() end
    function sim:step() self.t+=1 end
    local session=Session.new(1,0,0,sim)
    assert(not session:receive({epoch=2,commands={}},1),"old lifecycle")
    assert(session:receive({epoch=1,commands={{seq=2,tick=8,input={}}}},1))
    assert(session:advance(24,1)==0,"gap must hold validation")
    assert(session:receive({epoch=1,commands={{seq=1,tick=0,input={}}}},1))
    assert(session:advance(24,1)==16 and session.ack==2,"gap recovery")
    return true
end
return M
