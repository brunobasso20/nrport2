local P=require(script.Parent.PredictionProtocol)
local Codec=require(script.Parent.PredictionCheckpoint)
local Session=require(script.Parent.PredictionSession)
local M={}
function M.run()
    assert(P.input({steer=0/0})==nil,"nonfinite input")
    assert(P.input({throttle=2})==nil,"input range")
    assert(P.command({seq=2,tick=0,input={}},0)==nil,"tick sequence")
    local memory=buffer.create(4096);buffer.writeu32(memory,2048,123456)
    local packed=Codec.pack({memory=memory,tick=8,hosts={track={contacts={
        [0]={fx=11},[1]={fx=22},[2]={fx=33},[3]={fx=44}},R={[0]=5,[9]=6}},
        fpu={[0]=1,[6]=2}},sparse={[-1]=false,[0xc12030]=7,["0"]=8}})
    local function wire(value)
        if typeof(value)~="table" then return value end
        local out,n,count,array,dict={},#value,0,true,true
        for key in pairs(value) do
            count+=1;array=array and type(key)=="number" and key%1==0 and key>=1 and key<=n
            dict=dict and type(key)=="string"
        end
        assert((array and count==n) or dict,"unsafe checkpoint RemoteEvent table")
        for key,item in pairs(value) do out[key]=wire(item) end
        return out
    end
    local round=Codec.unpack(wire(packed))
    assert(buffer.tostring(round.memory)==buffer.tostring(memory),"checkpoint round trip")
    assert(round.hosts.track.contacts[0].fx==11 and round.hosts.track.contacts[3].fx==44,"zero-index contacts")
    assert(round.hosts.track.R[0]==5 and round.hosts.fpu[0]==1 and round.hosts.fpu[6]==2,"sparse machine state")
    assert(round.sparse[-1]==false and round.sparse[0xc12030]==7 and round.sparse["0"]==8,"host key types")
    local sim={t=0}
    function sim:tick() return self.t end
    function sim:state() return table.create(45,0) end
    function sim:shift() end
    function sim:step() self.t+=1 end
    local session=Session.new(1,0,0,sim)
    assert(not session:receive({epoch=2,commands={}},1),"old lifecycle")
    assert(session:receive({epoch=1,commands={{seq=2,tick=8,input={}}}},1))
    assert(session:advance(24,1)==0,"gap must hold validation")
    assert(session:receive({epoch=1,commands={{seq=1,tick=0,input={}}}},1))
    assert(session:advance(24,1)==16 and session.ack==2,"gap recovery")
    return true
end
return M
