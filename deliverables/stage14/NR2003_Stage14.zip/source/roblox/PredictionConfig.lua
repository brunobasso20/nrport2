-- Host/network policy only. None of these values changes NR2003 equations.
return table.freeze({
    version=14, hz=288, frameTicks=8,
    maxSteps=24, clientBudget=0.006, serverBudget=0.012,
    historyFrames=256, checkpointFrames=18, checkpointSlots=8,
    batchFrames=12, pendingFrames=256, sendHz=30, ackHz=10,
    leadTicks=72, maxPacketHz=90, timeout=3,
    positionTolerance=0.02, velocityTolerance=0.05, rotationTolerance=0.001,
    -- A visual offset may decay; it is never imported into simulation.
    smoothSeconds=0.10, snapMetres=2, pageBytes=1024,
})
