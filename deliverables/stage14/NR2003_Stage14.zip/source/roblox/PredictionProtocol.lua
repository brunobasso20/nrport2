local C=require(script and script.Parent.PredictionConfig or "./PredictionConfig")
local M={}
function M.finite(x) return type(x)=="number" and x==x and math.abs(x)<math.huge end
function M.integer(x,lo,hi) return M.finite(x) and x%1==0 and x>=lo and x<=hi end
local ranges={throttle={0,1},brake={0,1},clutch={0,1},handbrake={0,1},steer={-1,1},
    steerLeft={0,1},steerRight={0,1},steerAxis={-1,1},shift={-1,1}}
local flags={steerAnalog=true,brakeAxis=true,throttleAxis=true}
function M.input(raw)
    if type(raw)~="table" then return nil end
    local input={}
    for key,r in pairs(ranges) do
        local x=raw[key]
        if x==nil then x=0 end
        if not M.finite(x) or x<r[1] or x>r[2] or (key=="shift" and x%1~=0) then return nil end
        input[key]=x
    end
    for key in pairs(flags) do
        if raw[key]~=nil and type(raw[key])~="boolean" then return nil end
        input[key]=raw[key]==true
    end
    return input
end
function M.command(raw,startTick)
    if type(raw)~="table" or not M.integer(raw.seq,1,2147483647) or
        raw.tick~=startTick+(raw.seq-1)*C.frameTicks then return nil end
    local input=M.input(raw.input);if not input then return nil end
    return {seq=raw.seq,tick=raw.tick,input=input}
end
function M.same(a,b)
    if a.tick~=b.tick then return false end
    for k in pairs(ranges) do if a.input[k]~=b.input[k] then return false end end
    for k in pairs(flags) do if a.input[k]~=b.input[k] then return false end end
    return true
end
function M.witness(raw)
    if type(raw)~="table" or #raw~=45 then return nil end
    local t={};for i=1,45 do if not M.finite(raw[i]) then return nil end;t[i]=raw[i] end
    return t
end
function M.error(a,b)
    local pos,vel,rot,maximum=0,0,0,0
    for i=1,45 do maximum=math.max(maximum,math.abs(a[i]-b[i])) end
    for _,i in ipairs({1,3,5}) do pos+=(a[i]-b[i])^2 end
    for _,i in ipairs({2,4,6}) do vel+=(a[i]-b[i])^2 end
    for i=7,10 do rot=math.max(rot,math.abs(a[i]-b[i])) end
    pos=math.sqrt(pos);vel=math.sqrt(vel)
    return pos>C.positionTolerance or vel>C.velocityTolerance or rot>C.rotationTolerance,
        {position=pos,velocity=vel,rotation=rot,maximum=maximum}
end
return M
