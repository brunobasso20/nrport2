-- Lossless sparse pages against an immutable epoch baseline. No float quantization.
local M={}
function M.copy(x)
    if type(x)~="table" then return x end
    local t={};for k,v in pairs(x) do t[k]=M.copy(v) end;return t
end
function M.pack(c,base)
    local m=c.memory;local n=buffer.len(m);local page=1024
    local offsets,parts={},{}
    for off=0,n-1,page do
        local count=math.min(page,n-off)
        local s=buffer.readstring(m,off,count)
        local b=base and buffer.readstring(base,off,count) or string.rep("\0",count)
        if s~=b then offsets[#offsets+1]=off;parts[#parts+1]=s end
    end
    local h=M.copy(c);h.memory=nil
    return {size=n,offsets=offsets,data=buffer.fromstring(table.concat(parts)),host=h}
end
function M.unpack(p,base)
    assert(type(p)=="table" and p.size>0 and p.size<=32*1024*1024,"checkpoint size")
    if base then assert(buffer.len(base)==p.size,"checkpoint baseline size") end
    local m=buffer.create(p.size);if base then buffer.copy(m,0,base) end
    local cursor,last=0,-1
    for _,off in ipairs(p.offsets) do
        assert(type(off)=="number" and off%1024==0 and off>last and off<p.size,"checkpoint page")
        local n=math.min(1024,p.size-off)
        assert(cursor+n<=buffer.len(p.data),"checkpoint data")
        buffer.copy(m,off,p.data,cursor,n);cursor+=n;last=off
    end
    assert(cursor==buffer.len(p.data),"checkpoint trailing data")
    local c=M.copy(p.host);c.memory=m;return c
end
return M
