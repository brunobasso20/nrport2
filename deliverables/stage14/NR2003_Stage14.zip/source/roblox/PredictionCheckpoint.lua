-- Lossless sparse pages against an immutable epoch baseline. No float quantization.
local M={}
function M.copy(x)
    if typeof(x)~="table" then return x end
    local t={};for k,v in pairs(x) do t[k]=M.copy(v) end;return t
end
-- RemoteEvents do not preserve mixed/sparse numeric table keys. Keep every
-- native key (wheel 0, register 0, sparse x87 slots, addresses) as a VALUE in
-- a dense entry array. A flat node list also bounds wire nesting depth.
local function packHost(root)
    local nodes,ids={},{}
    local function visit(value)
        if ids[value] then return ids[value] end
        local id=#nodes+1;local entries={};nodes[id]=entries;ids[value]=id
        for key,item in pairs(value) do
            assert(type(key)=="string" or type(key)=="number","checkpoint host key")
            local kind=typeof(item)
            if kind=="table" then
                entries[#entries+1]={key,true,visit(item)}
            else
                assert(kind=="number" or kind=="boolean" or kind=="string" or kind=="buffer" or
                    kind=="CFrame" or kind=="Vector3","checkpoint host value: "..kind)
                entries[#entries+1]={key,false,item}
            end
        end
        return id
    end
    assert(visit(root)==1)
    return {version=1,nodes=nodes}
end
local function unpackHost(wire)
    assert(type(wire)=="table" and wire.version==1 and type(wire.nodes)=="table","checkpoint host wire format")
    local nodes=wire.nodes;assert(#nodes>=1 and #nodes<=4096,"checkpoint host nodes")
    local values={};for i=1,#nodes do values[i]={} end
    for i,entries in ipairs(nodes) do
        assert(type(entries)=="table" and #entries<=65536,"checkpoint host entries")
        local out=values[i]
        for _,entry in ipairs(entries) do
            assert(type(entry)=="table" and #entry==3 and type(entry[2])=="boolean","checkpoint host entry")
            local key,reference,item=entry[1],entry[2],entry[3]
            assert(type(key)=="string" or (type(key)=="number" and key==key),"checkpoint host key")
            assert(out[key]==nil,"checkpoint duplicate host key")
            if reference then
                assert(type(item)=="number" and item%1==0 and values[item],"checkpoint host reference")
                out[key]=values[item]
            else
                assert(typeof(item)~="table","checkpoint unexpected nested host value")
                out[key]=item
            end
        end
    end
    return values[1]
end
function M.pack(c,base)
    local m=c.memory;local n=buffer.len(m);local page=1024
    local offsets,parts={},{}
    for off=0,n-1,page do
        local count=math.min(page,n-off)
        local s=buffer.readstring(m,off,count)
        local b=base and buffer.readstring(base,off,count) or string.rep("\0",count)
        if s~=b then offsets[#offsets+1]=off;parts[#parts+1]=s end
    end
    local h=M.copy(c);h.memory=nil
    return {size=n,offsets=offsets,data=buffer.fromstring(table.concat(parts)),host=packHost(h)}
end
function M.unpack(p,base)
    assert(type(p)=="table" and p.size>0 and p.size<=32*1024*1024,"checkpoint size")
    if base then assert(buffer.len(base)==p.size,"checkpoint baseline size") end
    local m=buffer.create(p.size);if base then buffer.copy(m,0,base) end
    local cursor,last=0,-1
    for _,off in ipairs(p.offsets) do
        assert(type(off)=="number" and off%1024==0 and off>last and off<p.size,"checkpoint page")
        local n=math.min(1024,p.size-off)
        assert(cursor+n<=buffer.len(p.data),"checkpoint data")
        buffer.copy(m,off,p.data,cursor,n);cursor+=n;last=off
    end
    assert(cursor==buffer.len(p.data),"checkpoint trailing data")
    local c=unpackHost(p.host);c.memory=m;return c
end
return M
