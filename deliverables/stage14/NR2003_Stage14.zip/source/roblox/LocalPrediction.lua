local C=require(script and script.Parent.PredictionConfig or "./PredictionConfig")
local Codec=require(script and script.Parent.PredictionCheckpoint or "./PredictionCheckpoint")
local P=require(script and script.Parent.PredictionProtocol or "./PredictionProtocol")
local M={};M.__index=M
function M.new(sim,epoch,initial)
    sim:restore(initial)
    return setmetatable({sim=sim,epoch=epoch,startTick=sim:tick(),ack=0,ackTick=sim:tick(),commands={},
        states={},backlog=0,reconciliations=0,hardResyncs=0,correction=0,slots={},base=initial.memory,
        lastAck=-1,cpu=0,steps=0,rtt=0},M)
end
function M:advance(elapsed,sample,budget)
    assert(P.finite(elapsed) and elapsed>=0,"elapsed")
    self.backlog+=elapsed
    local start=os.clock();local count=0
    while (self.backlog+1e-12>=1/288 or (self.replayUntil and self.sim:tick()<self.replayUntil)) and count<C.maxSteps and
        (count==0 or os.clock()-start<(budget or C.clientBudget)) do
        local tick=self.sim:tick();local seq=math.floor((tick-self.startTick)/8)+1
        local cmd=self.commands[seq]
        local replay=self.replayUntil and tick<self.replayUntil
        if tick%8==0 and not replay then
            local input=assert(P.input(sample()),"local input")
            cmd={seq=seq,tick=tick,input=input};self.commands[seq]=cmd
        end
        assert(cmd,"missing current command")
        if tick%8==0 and cmd.input.shift~=0 then self.sim:shift(cmd.input.shift) end
        self.sim:step(cmd.input);if not replay then self.backlog-=1/288 end;count+=1
        if self.replayUntil and self.sim:tick()>=self.replayUntil then self.replayUntil=nil end
        if self.sim:tick()%8==0 then
            self.states[seq]=table.clone(self.sim:state())
            if seq%C.checkpointFrames==0 then
                self.slots[#self.slots+1]={tick=self.sim:tick(),state=Codec.pack(self.sim:checkpoint(),self.base)}
                if #self.slots>C.checkpointSlots then table.remove(self.slots,1) end
            end
            self.commands[seq-C.historyFrames]=nil;self.states[seq-C.historyFrames]=nil
        end
    end
    if math.abs(self.backlog)<1e-12 then self.backlog=0 end
    self.steps+=count;self.cpu+=os.clock()-start;return count
end
function M:packet(now)
    local latest=math.floor((self.sim:tick()-self.startTick)/8)
    local commands={}
    for seq=self.ack+1,math.min(latest+1,self.ack+C.batchFrames) do
        if self.commands[seq] then commands[#commands+1]=self.commands[seq] end
    end
    -- Witness only for a frame included in this packet. Server compares at the SAME tick.
    local seq=commands[#commands] and math.min(commands[#commands].seq,latest)
    return {kind="commands",epoch=self.epoch,commands=commands,echo=now,
        witness=seq and self.states[seq] and {seq=seq,tick=self.startTick+seq*8,state=self.states[seq]} or nil}
end
function M:acknowledge(message,now)
    if message.epoch~=self.epoch or not P.integer(message.ack,0,2147483647) or
        message.tick~=self.startTick+message.ack*8 or message.ack<self.ack then return false end
    if message.tick>self.sim:tick() then return false end
    self.ack,self.ackTick=message.ack,message.tick
    if P.finite(message.echo) and now>=message.echo then self.ackRTT=now-message.echo end
    if message.checkpoint and message.tick>self.lastAck then
        local oldTick=math.max(self.sim:tick(),self.replayUntil or 0);local canReplay=oldTick-message.tick<=C.historyFrames*8
        for tick=message.tick,oldTick-1,8 do
            local seq=math.floor((tick-self.startTick)/8)+1
            if not self.commands[seq] then canReplay=false;break end
        end
        self.sim:restore(Codec.unpack(message.checkpoint,self.base))
        assert(self.sim:tick()==message.tick,"mixed checkpoint ticks")
        if canReplay then
            self.replayUntil=oldTick
        else
            self.hardResyncs+=1;self.commands={};self.states={};self.replayUntil=nil
        end
        self.slots={};self.reconciliations+=1;self.correction=message.error and message.error.position or 0
        self.lastAck=message.tick
    end
    return true
end
function M:stats()
    return {tick=self.sim:tick(),ack=self.ack,ackTick=self.ackTick,
        unacknowledged=math.max(0,math.ceil((self.sim:tick()-self.startTick)/8)-self.ack),
        rtt=self.rtt,backlog=self.backlog,reconciliations=self.reconciliations,correction=self.correction,
        hardResyncs=self.hardResyncs,cpu=self.cpu,steps=self.steps,replayTicks=math.max(0,(self.replayUntil or 0)-self.sim:tick())}
end
return M
