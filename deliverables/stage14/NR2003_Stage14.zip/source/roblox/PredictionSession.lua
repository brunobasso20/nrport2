-- Pure scheduling/ordering: server never consumes client poses or client clock values.
local C=require(script and script.Parent.PredictionConfig or "./PredictionConfig")
local P=require(script and script.Parent.PredictionProtocol or "./PredictionProtocol")
local M={};M.__index=M
function M.new(epoch,startTick,now,sim)
    assert(startTick%8==0,"session must start on a device boundary")
    return setmetatable({epoch=epoch,startTick=startTick,started=now,sim=sim,ack=0,pending={},
        witnesses={},acceptedStates={},verifiedWitnesses={},lastPacket=now,lastReceive=now,tokens=C.maxPacketHz,rejected=0,steps=0,cpu=0},M)
end
function M:receive(packet,now)
    if type(packet)~="table" or packet.epoch~=self.epoch then return false,"epoch" end
    local refill=math.max(0,now-self.lastPacket)*C.maxPacketHz
    self.tokens=math.min(C.maxPacketHz,self.tokens+refill);self.lastPacket=now
    if self.tokens<1 then return false,"rate" end;self.tokens-=1
    if type(packet.commands)~="table" or #packet.commands>C.batchFrames then return false,"batch" end
    local accepted={}
    for _,raw in ipairs(packet.commands) do
        local cmd=P.command(raw,self.startTick)
        if not cmd then return false,"command" end
        if cmd.seq>self.ack+C.pendingFrames then return false,"window" end
        if cmd.tick+8>self.startTick+math.floor(math.max(0,now-self.started)*288)+C.leadTicks then return false,"timing" end
        if self.pending[cmd.seq] and not P.same(cmd,self.pending[cmd.seq]) then return false,"conflicting command" end
        accepted[#accepted+1]=cmd
    end
    local witnessSeq,witnessState
    if packet.witness then
        local w=packet.witness
        if not P.integer(w.seq,1,self.ack+C.pendingFrames) or
            w.tick~=self.startTick+w.seq*8 then return false,"witness tick" end
        local state=P.witness(w.state);if not state then return false,"witness" end
        witnessSeq,witnessState=w.seq,state
    end
    for _,cmd in ipairs(accepted) do if cmd.seq>self.ack then self.pending[cmd.seq]=cmd end end
    if witnessSeq and witnessSeq>self.ack then self.witnesses[witnessSeq]=witnessState end
    if witnessSeq and witnessSeq<=self.ack and self.acceptedStates[witnessSeq] and self.onWitness and not self.verifiedWitnesses[witnessSeq] then
        self.verifiedWitnesses[witnessSeq]=true
        self.onWitness(witnessSeq,self.acceptedStates[witnessSeq],witnessState)
    end
    self.lastReceive=now;self.echo=P.finite(packet.echo) and packet.echo or nil;return true
end
function M:advance(maxTicks,budget,onFrame)
    local start=os.clock();local count=0
    while count<maxTicks and (count==0 or os.clock()-start<budget) do
        local cmd=self.pending[self.ack+1]
        if not cmd then break end -- a gap stops verification, never the local predictor
        if self.sim:tick()==cmd.tick and cmd.input.shift~=0 then self.sim:shift(cmd.input.shift) end
        self.sim:step(cmd.input);count+=1
        if self.sim:tick()==cmd.tick+8 then
            self.ack=cmd.seq;self.pending[cmd.seq]=nil
            self.acceptedStates[cmd.seq]=table.clone(self.sim:state())
            self.acceptedStates[cmd.seq-C.pendingFrames]=nil
            self.verifiedWitnesses[cmd.seq-C.pendingFrames]=nil
            local w=self.witnesses[cmd.seq];self.witnesses[cmd.seq]=nil
            if w and self.onWitness and not self.verifiedWitnesses[cmd.seq] then
                self.verifiedWitnesses[cmd.seq]=true;self.onWitness(cmd.seq,self.acceptedStates[cmd.seq],w)
            end
            if onFrame then onFrame(cmd,w) end
        end
    end
    self.steps+=count;self.cpu+=os.clock()-start;return count
end
return M
