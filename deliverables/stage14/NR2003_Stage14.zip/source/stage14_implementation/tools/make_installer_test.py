from pathlib import Path
import json,subprocess,xml.etree.ElementTree as E
r=Path(__file__).resolve().parents[2];manifest=json.loads((r/'stage14_implementation/studio/manifest.json').read_text())
sources={};originals={}
def old(path):
 p=r/'work/stage14/baseline'/path
 return p.read_text() if p.exists() else subprocess.check_output(['git','show','HEAD:'+path],cwd=r).decode()
for i in manifest['items']:
 if 'old' in i: originals[i['key']]=old(i['file'])
 if i.get('server'): originals[i['key']]=old('nr2003carmodel_implementation/roblox/Bench/Server.server.lua').split('-- Stage 14:')[0] if False else subprocess.check_output(['git','show','HEAD:nr2003carmodel_implementation/roblox/Bench/Server.server.lua'],cwd=r).decode()
 if not i.get('server'):sources[i['key']]=(r/i['file']).read_text()
mapping=json.loads((r/'work/stage14/baseline_map.json').read_text())
for d in manifest['dependencies']:
 key=d['key'];parts=key.split('.')
 path=mapping.get(key)
 if not path:
  path={'Core':'core/','Roblox':'roblox/','CarModel':'nr2003carmodel_implementation/roblox/CarModel/'}[parts[0]]+'/'.join(parts[1:])+'.lua'
 originals[key]=old(path)
parts=['local SOURCES={}\nlocal ORIGINALS={}\n']
def ls(s):
 eq='='
 while ']'+eq+']' in s:eq+='='
 return '['+eq+'[\n'+s+']'+eq+']'
for k,s in sources.items():parts.append('SOURCES[%r]=%s\n'%(k,ls(s)))
for k,s in originals.items():parts.append('ORIGINALS[%r]=%s\n'%(k,ls(s)))
for n in ['Apply','Support','Manifest','Rollback']:parts.append('local '+n.upper()+'='+ls((r/'stage14_implementation/studio'/f'{n}.lua').read_text())+'\n')
legacy=r/'work/stage14/fix1-before/studio/NR2003_Stage14_Install.rbxmx'
parts.append('local LEGACY={}\n')
for item in E.parse(legacy).getroot().iter('Item'):
 props=item.find('Properties')
 if props is None:continue
 name=props.find("string[@name='Name']");source=props.find("ProtectedString[@name='Source']")
 if name is not None and source is not None:parts.append('LEGACY[%r]=%s\n'%(name.text,ls(source.text or '')))
base=(r/'tools/patch_mock_body.luau').read_text().split('-- 1) install on a Stage 5 bench')[0]
base=base.replace('script = m, require = mockRequire, game = game, workspace = services.Workspace',
                  'script = m, require = mockRequire, game = game, workspace = services.Workspace, Instance=Instance')
base=base.replace('Archivable = true, _parent = nil','Archivable = true, Source = "", _parent = nil')
base=base.replace('"  " .. detail','"  " .. tostring(detail)')
parts.append(base)
parts.append((r/'stage14_implementation/tests/installer_tail.luau').read_text())
(r/'stage14_implementation/tests/installer_mock.luau').write_text(''.join(parts))
