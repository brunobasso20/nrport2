from pathlib import Path
r=Path(__file__).resolve().parents[2]
files=['PredictionServer','PredictionClient','PredictionConfig','PredictionProtocol','PredictionSession','PredictionCheckpoint','LocalPrediction']
parts=['local SOURCES={}\n']
for n in files:
 s=(r/'roblox'/f'{n}.lua').read_text();eq='='
 while ']'+eq+']' in s:eq+='='
 parts.append('SOURCES[%r]=[%s[\n%s]%s]\n'%('Roblox.'+n,eq,s,eq))
math=(r/'tools/adapter_mock_body.luau').read_text().split('-- world: ground plane')[0]
parts.append(math)
parts.append('CFrame.identity=CFrame.new()\n')
parts.append((r/'stage14_implementation/tests/runtime_body.luau').read_text())
(r/'stage14_implementation/tests/runtime_mock.luau').write_text(''.join(parts))
