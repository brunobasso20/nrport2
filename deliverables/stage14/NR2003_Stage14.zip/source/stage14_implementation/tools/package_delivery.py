from pathlib import Path
import shutil,hashlib,zipfile,json,xml.etree.ElementTree as E,subprocess
R=Path(__file__).resolve().parents[2]
P=R/'work/stage14/package'
O=Path('/codex/browser/projectless/0004-files-mentioned-by-the-user-uploaded-file-pointe/output')
if P.exists():shutil.rmtree(P)
P.mkdir(parents=True,exist_ok=True);O.mkdir(parents=True,exist_ok=True)
def copy(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
D=R/'stage14_implementation/studio'
copy(D/'NR2003_Stage14_Install.rbxmx',P/'NR2003_Stage14_Fix1_Install.rbxmx')
for name in ['INSTALL_STAGE14.lua','ROLLBACK_STAGE14.lua']:copy(D/name,P/name)
for name in ['README.md','STAGE14_REPORT.md','STAGE14_FIX1.md']:copy(R/'stage14_implementation'/name,P/name)
# Complete reconstructed runtime for review and reproducible headless Stage 14 tests.
for directory in ['core','roblox','watkinsglen_implementation/core','nr2003carmodel_implementation/roblox/CarModel','nr2003carmodel_implementation/roblox/Bench','stage14_implementation']:
 for path in (R/directory).rglob('*'):
  if path.is_file() and path.suffix in ['.lua','.luau','.py','.md','.json','.rbxmx'] and '__pycache__' not in path.parts:
   copy(path,P/'source'/path.relative_to(R))
for path in ['default.project.json','LICENSE_UPSTREAM.txt','tools/adapter_mock_body.luau','tools/patch_mock_body.luau']:
 copy(R/path,P/'source'/path)
for name in ['results.log','remote_checkpoint.log','runtime.log','adapter_native.log','installer.log','profile.log','regression10.log','regression13.log','syntax.log']:
 copy(R/'work/stage14'/name,P/'validation'/name)
copy(R/'work/stage14/uploads/WatkinsGlen_RoadCourse_Patch_V6/VALIDATION.md',P/'validation/V6_INHERITED_VALIDATION.md')
# Verify the exact shipped model payload against the pinned manifest.
manifest=json.loads((D/'manifest.json').read_text())
xml=E.parse(P/'NR2003_Stage14_Fix1_Install.rbxmx').getroot();payload={}
for item in xml.iter('Item'):
 props=item.find('Properties')
 if props is None:continue
 name=props.find("string[@name='Name']");source=props.find("ProtectedString[@name='Source']")
 if name is not None and source is not None:payload[name.text]=source.text or ''
def fp(s):
 b=s.replace('\r\n','\n').replace('\r','\n').encode();h=2166136261
 for x in b:h=((h^x)*16777619)&0xffffffff
 return {'bytes':len(b),'fnv32':h}
for item in manifest['items']:
 if not item.get('server'):assert fp(payload[item['key']])==item['new'],item['key']
assert len([i for i in manifest['items'] if not i.get('server')])==20
# A clean artifact can rebuild the model without the original checkout/attachments.
subprocess.run(['python3','stage14_implementation/tools/build.py'],cwd=P/'source',check=True,capture_output=True)
assert (P/'source/stage14_implementation/studio/NR2003_Stage14_Install.rbxmx').read_bytes()==(P/'NR2003_Stage14_Fix1_Install.rbxmx').read_bytes()
checks=[]
for file in sorted(P.rglob('*')):
 if file.is_file() and file.name!='SHA256SUMS.txt':checks.append(hashlib.sha256(file.read_bytes()).hexdigest()+'  '+file.relative_to(P).as_posix())
(P/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n')
zip_path=O/'NR2003_Stage14_Fix1.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(P.rglob('*')):
  if file.is_file():z.write(file,file.relative_to(P))
for name in ['README.md','STAGE14_REPORT.md','STAGE14_FIX1.md','NR2003_Stage14_Fix1_Install.rbxmx']:copy(P/name,O/name)
# Update the previous download names as aliases, while new names avoid stale caches.
copy(zip_path,O/'NR2003_Stage14.zip')
copy(P/'NR2003_Stage14_Fix1_Install.rbxmx',O/'NR2003_Stage14_Install.rbxmx')
names=['NR2003_Stage14_Fix1.zip','NR2003_Stage14_Fix1_Install.rbxmx']
(O/'STAGE14_FIX1_SHA256SUMS.txt').write_text(''.join(hashlib.sha256((O/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in names))
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
print('Verified model:',manifest['bundle'],'20 exact source payloads plus preserved server dispatcher')
print('Verified self-contained artifact rebuild and ZIP CRC')
print('Delivery:',zip_path,'bytes',zip_path.stat().st_size,'files',len(checks)+1)
