from pathlib import Path
root=Path(__file__).resolve().parents[2]
files=['core/NR2003CupVehicle.lua','core/CupTune.lua','core/NR2003FixedStep.lua','core/NR2003Math.lua','core/Float32.lua','core/Surface.lua','core/RecoveredData.lua','core/MathUtil.lua','core/TestTune.lua','roblox/RenderSnapshot.lua','roblox/CupChassisAdapter.lua','roblox/NR2003WatkinsGlen.lua','roblox/NR2003WatkinsGlenSetup.lua','roblox/PredictionSimulation.lua','roblox/PredictionCheckpoint.lua']
parts=['local SOURCES={}\n']
for file in files:
 key=file.replace('core/','Core.').replace('roblox/','Roblox.').removesuffix('.lua')
 text=(root/file).read_text();eq='='
 while ']'+eq+']' in text:eq+='='
 parts.append('SOURCES[%r]=[%s[\n%s]%s]\n'%(key,eq,text,eq))
body=(root/'tools/adapter_mock_body.luau').read_text().split('-- ===== scenario =====')[0]
body=body.replace('local ok, v = pcall(require, "../../core/NR2003Cup/" .. m)', 'local ok, v = pcall(require, "../../core/NR2003Cup/" .. m)\n            if not ok then ok,v=pcall(require,"../../watkinsglen_implementation/core/NR2003Cup/"..m) end')
parts.append(body)
parts.append((root/'stage14_implementation/tests/adapter_tail.luau').read_text())
(root/'stage14_implementation/tests/adapter_integration.luau').write_text(''.join(parts))
