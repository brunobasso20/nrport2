"""Idempotent checkpoint augmentation; equations and calibration are untouched."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
def change(path,old,new):
    p=ROOT/path;s=p.read_text()
    if new in s:return
    assert s.count(old)==1,(path,s.count(old))
    p.write_text(s.replace(old,new))
def hook(path,name,capture,restore):
    p=ROOT/path;s=p.read_text()
    marker='-- Stage 14 checkpoint: '+name
    if marker in s:return
    block=f'''\n\t{marker}
\tV._registerCheckpoint("{name}", function() return {capture} end, function(h)
{restore}
\tend)
'''
    anchor='\treturn V\nend'
    if anchor not in s:anchor='\tV._trackCtx = ctx\nend';block+='\tV._trackCtx = ctx\nend';s=s.replace(anchor,block)
    else:s=s.replace(anchor,block+anchor)
    p.write_text(s)

change('core/NR2003Cup/NR2003CupCore.lua','function V.checkpoint()','''-- Stage 14: closures are simulation state too. Registration never stores functions in packets.
local checkpointHooks = {}
local function copyState(x)
    if type(x) ~= "table" then return x end
    local t = {}; for k, v in pairs(x) do t[k] = copyState(v) end; return t
end
V._copyState = copyState
function V._registerCheckpoint(name, capture, restore)
    checkpointHooks[name] = {capture, restore}
end
function V.checkpoint()''')
change('core/NR2003Cup/NR2003CupCore.lua','return { memory = c, tick = V.tick }','''local hosts = {}
    for name, h in pairs(checkpointHooks) do hosts[name] = copyState(h[1]()) end
    return { memory = c, tick = V.tick, schema = 14, hosts = hosts,
        machine = {EAX, EBX, ECX, EDX, ESI, EDI, EBP, ESP, FT, FSW, FCW, FR, FZ, FS, FC, FO, FP, BG},
        fpu = table.clone(F) }''')
change('core/NR2003Cup/NR2003CupCore.lua','\tV.tick = c.tick\nend','''    assert(buffer.len(c.memory) == Image.size, "checkpoint memory size")
    V.tick = c.tick
    if c.schema == 14 then
        local r = c.machine
        EAX, EBX, ECX, EDX, ESI, EDI, EBP, ESP, FT, FSW, FCW = table.unpack(r, 1, 11)
        FR, FZ, FS, FC, FO, FP, BG = table.unpack(r, 12, 18)
        table.clear(F); for k, v in pairs(c.fpu) do F[k] = v end
        for name, h in pairs(checkpointHooks) do
            assert(c.hosts[name] ~= nil, "checkpoint host missing: " .. name)
            h[2](copyState(c.hosts[name]))
        end
    end
end''')
hook('core/NR2003Cup/NR2003CupAero.lua','aero',
     '{session=session, draftEnv=draftEnv, trackNormal=trackNormal}',
     '\t\tsession, draftEnv, trackNormal = h.session, h.draftEnv, h.trackNormal')
hook('core/NR2003Cup/NR2003CupFrame.lua','runtime',
     '{mode=mode, session=session11, R=ctx.R, F=ctx.F}',
     '\t\tmode, session11 = h.mode, h.session\n\t\tfor k,v in pairs(h.R) do ctx.R[k]=v end\n\t\ttable.clear(ctx.F);for k,v in pairs(h.F) do ctx.F[k]=v end')
hook('core/NR2003Cup/NR2003CupSteering.lua','steering',
     '{mode=mode, options=options, baseRate=baseRate, lockK=lockK, drawLimit=drawLimit, shaped=lastShaped, ratio=lastRatio, target=lastTarget, sensitivity=sensitivity, yawLimiterFactor=yawLimiterFactor}',
     '\t\tmode, options, lockK, drawLimit = h.mode, h.options, h.lockK, h.drawLimit\n\t\tbaseRate = h.baseRate\n\t\tlastShaped, lastRatio, lastTarget = h.shaped, h.ratio, h.target\n\t\tsensitivity, yawLimiterFactor = h.sensitivity, h.yawLimiterFactor')
hook('core/NR2003Cup/NR2003CupFFB.lua','ffb',
     '{device=device, effect=effect, kind=configuredKind, options=options, last=last}',
     '\t\tdevice, effect, configuredKind, options = h.device, h.effect, h.kind, h.options\n\t\tfor k,v in pairs(h.last) do last[k]=v end')
# Garage callback selection is persistent host state. Save the name, never a closure.
change('core/NR2003Cup/NR2003CupGarage.lua','\tlocal function selectCode(structure)','\tlocal selectedCode = "natural"\n\tlocal function selectCode(structure)\n\t\tselectedCode = structure == "generic" and "generic" or "natural"')
change('core/NR2003Cup/NR2003CupGarage.lua','\tfunction V._garageUseCode(name)','\tfunction V._garageUseCode(name)\n\t\tselectedCode = name')
hook('core/NR2003Cup/NR2003CupGarage.lua','garage',
     '{active=active, current=current, selected=selectedCode}',
     '\t\tactive, current = h.active, h.current\n\t\tV._garageUseCode(h.selected)\n\t\tif V._bindDriverCells then V._bindDriverCells() end')
hook('watkinsglen_implementation/core/NR2003Cup/NR2003CupTrack.lua','track',
     '{loaded=loaded, active=active, start=start, contacts=contacts, R=ctx.R, F=ctx.F}',
     '\t\tloaded, active, start = h.loaded, h.active, h.start\n\t\tcontacts = h.contacts\n\t\tfor k,v in pairs(h.R) do ctx.R[k]=v end\n\t\ttable.clear(ctx.F);for k,v in pairs(h.F) do ctx.F[k]=v end')
