from pathlib import Path
from xml.sax.saxutils import escape
import subprocess,json,hashlib
R=Path(__file__).resolve().parents[2]
D=R/'stage14_implementation/studio'
PINNED=json.loads((D/'manifest.json').read_text()) if (D/'manifest.json').exists() else {}
def norm(s):return s.replace('\r\n','\n').replace('\r','\n')
def fp(s):
 b=norm(s).encode();h=2166136261
 for x in b:h=((h^x)*16777619)&0xffffffff
 return {'bytes':len(b),'fnv32':h}
def old(path):
 p=R/'work/stage14/baseline'/path
 return norm(p.read_text()) if p.exists() else norm(subprocess.check_output(['git','show','HEAD:'+path],cwd=R).decode())
def lua(v):
 if v is None:return 'nil'
 if isinstance(v,bool):return str(v).lower()
 if isinstance(v,(int,float)):return repr(v)
 if isinstance(v,str):return json.dumps(v,ensure_ascii=False)
 if isinstance(v,list):return '{'+','.join(lua(x) for x in v)+'}'
 return '{'+','.join('['+lua(k)+']='+lua(x) for k,x in v.items())+'}'
changed={
 **{'Core.NR2003Cup.'+n:'core/NR2003Cup/'+n+'.lua' for n in ['NR2003CupCore','NR2003CupAero','NR2003CupFrame','NR2003CupGarage','NR2003CupSteering','NR2003CupFFB']},
 'Core.NR2003Cup.NR2003CupTrack':'watkinsglen_implementation/core/NR2003Cup/NR2003CupTrack.lua',
 'Roblox.CupChassisAdapter':'roblox/CupChassisAdapter.lua',
 'Roblox.RenderPresentation':'roblox/RenderPresentation.lua',
 'Client.NR2003Client':'nr2003carmodel_implementation/roblox/Bench/Client.client.lua',
 'CarModel.NR2003CarModelClient':'nr2003carmodel_implementation/roblox/CarModel/NR2003CarModelClient.lua',
}
new=['PredictionConfig','PredictionCheckpoint','PredictionProtocol','PredictionSession','LocalPrediction','PredictionSimulation','PredictionServer','PredictionClient','Stage14SelfTest']
items=[];sources={}
for key,path in sorted(changed.items()):
 source=norm((R/path).read_text())
 previous=next((i['old'] for i in PINNED.get('items',[]) if i['key']==key),None)
 if previous is None:previous=fp(old(path))
 cls='LocalScript' if key.startswith('Client.') else 'ModuleScript'
 assert fp(source)!=previous,key
 sources[key]=source;items.append({'key':key,'class':cls,'old':previous,'new':fp(source),'file':path})
for name in new:
 key='Roblox.'+name;path='roblox/'+name+'.lua';source=(R/path).read_text()
 sources[key]=source;items.append({'key':key,'class':'ModuleScript','new':fp(source),'file':path})
server=norm((R/'roblox/Server.server.lua').read_text());prefix=server.split('local RS=',1)[0]
items.append({'key':'Server.NR2003Server','class':'Script','server':True,'file':'roblox/Server.server.lua'})
v6path=R/'work/stage14/v6_manifest.json'
v6=json.loads(v6path.read_text()) if v6path.exists() else {'dependencies':PINNED['dependencies'],'targets':[]}
keys={i['key'] for i in items}
deps=[d for d in v6['dependencies'] if d['key'] not in keys]
for t in v6['targets']:
 if t['key'] not in keys:deps.append({'key':t['key'],'class':t['class'],'accepted':[t['new']]})
# Existing DrawState format and the 0.28m/stud car model adapter are reused without changes.
for name in ['NR2003DrawState','NR2003Scale']:
 path='nr2003carmodel_implementation/roblox/CarModel/'+name+'.lua'
 if not any(d['key']=='CarModel.'+name for d in deps):
  deps.append({'key':'CarModel.'+name,'class':'ModuleScript','accepted':[fp((R/path).read_text())]})
bundle='stage14-'+hashlib.sha256(json.dumps([fp(sources[k]) for k in sorted(sources)]).encode()).hexdigest()[:16]
manifest={'version':14,'bundle':bundle,'items':items,'dependencies':deps,'serverPrefix':prefix}
(D/'Manifest.lua').write_text('return '+lua(manifest)+'\n')
(D/'manifest.json').write_text(json.dumps(manifest,indent=2))
ref=[0]
def item(name,cls,source=None,children=''):
 ref[0]+=1
 props='<string name="Name">'+escape(name)+'</string>'
 if source is not None:
  assert len(source)<199000,name
  props+='<ProtectedString name="Source">'+escape(source)+'</ProtectedString>'
 return '<Item class="'+cls+'" referent="RBX'+str(ref[0])+'"><Properties>'+props+'</Properties>'+children+'</Item>'
payload=''.join(item(k,'ModuleScript',s) for k,s in sources.items())
modules=''.join(item(n,'ModuleScript',(D/(n+'.lua')).read_text()) for n in ['Apply','Support','Manifest','Rollback'])
xml='<roblox version="4">'+item('NR2003_Stage14_Install','Model',children=modules+item('Sources','Folder',children=payload))+'</roblox>'
(D/'NR2003_Stage14_Install.rbxmx').write_text(xml)
(D/'INSTALL_STAGE14.lua').write_text('require(workspace.NR2003_Stage14_Install.Apply)()\n')
(D/'ROLLBACK_STAGE14.lua').write_text('require(game.ServerStorage.NR2003Backup_Stage14.Rollback)()\n')
print(bundle,len(items),'changes',len(deps),'V6 dependency checks',len(xml),'model bytes')
