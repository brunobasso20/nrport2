local SES=game:GetService("ScriptEditorService")
local M={}
M.BACKUP="NR2003Backup_Stage14"
function M.normal(s) return (s:gsub("\r\n","\n"):gsub("\r","\n")) end
function M.fingerprint(s)
    s=M.normal(s);local h=2166136261
    for i=1,#s do h=bit32.bxor(h,string.byte(s,i));h=(h*403+bit32.band(h,255)*16777216)%4294967296 end
    return {bytes=#s,fnv32=h}
end
function M.matches(s,h) local a=M.fingerprint(s);return h and a.bytes==h.bytes and a.fnv32==h.fnv32 end
function M.source(o)
    local s=SES:GetEditorSource(o)
    assert(M.normal(s)==M.normal(o.Source),"Save open editor before operation: "..o:GetFullName());return s
end
function M.write(o,s,before)
    SES:UpdateSourceAsync(o,function(current)
        assert(M.normal(current)==M.normal(before),"Concurrent source edit: "..o:GetFullName());return s
    end)
    assert(M.normal(M.source(o))==M.normal(s),"Incomplete source write: "..o:GetFullName())
end
function M.child(p,n,optional)
    local got;for _,c in ipairs(p:GetChildren()) do if c.Name==n then assert(not got,"Duplicate name: "..n);got=c end end
    assert(got or optional,"Missing: "..p:GetFullName().."."..n);return got
end
function M.resolve(key,optional)
    local pkg=M.child(game:GetService("ReplicatedStorage"),"NR2003Lab")
    local roots={Core=pkg.Core,Roblox=pkg.Roblox,CarModel=pkg:FindFirstChild("CarModel"),
        Server=game:GetService("ServerScriptService"),Client=game:GetService("StarterPlayer").StarterPlayerScripts}
    local parts=string.split(key,".");local parent=assert(roots[parts[1]],"Missing root: "..key)
    for i=2,#parts-1 do parent=M.child(parent,parts[i]) end
    return M.child(parent,parts[#parts],optional),parent,parts[#parts]
end
function M.lock(fn)
    assert(not game:GetService("RunService"):IsRunning(),"Stop Play/Run before Stage 14 install or rollback")
    local ss=game:GetService("ServerStorage")
    assert(not ss:FindFirstChild("NR2003WatkinsGlenOperation"),"Another NR2003 operation is running")
    local lock=Instance.new("Folder");lock.Name="NR2003WatkinsGlenOperation";lock.Parent=ss
    local result=table.pack(pcall(fn));lock:Destroy()
    if not result[1] then error(result[2],0) end
    return table.unpack(result,2,result.n)
end
function M.records(backup,manifest)
    assert(backup:GetAttribute("Bundle")==manifest.bundle,"Backup belongs to a different Stage 14 build")
    local records=M.child(backup,"Records");local list={}
    assert(#records:GetChildren()==#manifest.items,"Incomplete Stage 14 backup")
    for _,item in ipairs(manifest.items) do
        local e=M.child(records,item.key);local target=M.child(e,"Target")
        local object=M.resolve(item.key,true)
        assert(target.Value==object,"Target instance changed: "..item.key)
        local old=M.child(e,"Original",true)
        if old then
            assert(M.matches(M.source(old),{bytes=e:GetAttribute("OldBytes"),fnv32=e:GetAttribute("OldHash")}),"Damaged original backup: "..item.key)
            if item.old then assert(M.matches(M.source(old),item.old),"Original backup differs from V6: "..item.key) end
        end
        local new=M.child(e,"Installed")
        assert(M.matches(M.source(new),{bytes=e:GetAttribute("NewBytes"),fnv32=e:GetAttribute("NewHash")}),"Damaged installed backup: "..item.key)
        if not item.server then assert(M.matches(M.source(new),item.new),"Backup source mismatch: "..item.key) end
        if item.server then assert(old and M.normal(M.source(new))==M.normal(manifest.serverPrefix..M.source(old)),"Server backup mismatch") end
        list[#list+1]={item=item,entry=e,object=object,old=old and M.source(old),new=M.source(new)}
    end
    return list
end
function M.restore(backup,manifest,archive)
    local list=M.records(backup,manifest)
    -- Check all live sources before changing any of them.
    for _,r in ipairs(list) do
        if r.object then
            local live=M.source(r.object)
            assert(M.normal(live)==M.normal(r.new) or (r.old and M.normal(live)==M.normal(r.old)) or
                (not backup:GetAttribute("Complete") and not r.old and live==""),"Local edits prevent rollback: "..r.item.key)
        else assert(not r.old,"Original target disappeared: "..r.item.key) end
    end
    for _,r in ipairs(list) do
        if r.old then M.write(r.object,r.old,M.source(r.object)) end
    end
    -- Added modules are removed only after every original source was restored.
    for _,r in ipairs(list) do if not r.old and r.object then r.object:Destroy() end end
    local pkg=game:GetService("ReplicatedStorage").NR2003Lab
    pkg:SetAttribute("NR2003Stage14",backup:GetAttribute("PreviousStage14"))
    backup:SetAttribute("RolledBack",true)
    if archive then
        local name=M.BACKUP.."_RolledBack_"..os.time();local n=1;local unique=name
        while backup.Parent:FindFirstChild(unique) do n+=1;unique=name.."_"..n end
        backup.Name=unique
    end
end
return M
