return function()
    local backup=script.Parent;local H=require(backup.Support);local manifest=require(backup.Manifest)
    return H.lock(function()
        H.restore(backup,manifest,true)
        print("Stage 14 rolled back to the exact preceding V6 sources. Backup retained as "..backup.Name)
        return true
    end)
end
