return function()
    local install=script.Parent;local H=require(install.Support);local manifest=require(install.Manifest)
    return H.lock(function()
        local pkg=game:GetService("ReplicatedStorage").NR2003Lab
        assert(pkg:GetAttribute("NR2003Track")=="watkins_glen","Install supplied Watkins Glen V6 first")
        local oldBackup=game:GetService("ServerStorage"):FindFirstChild(H.BACKUP)
        if oldBackup then
            assert(oldBackup:GetAttribute("Complete")==true and not oldBackup:GetAttribute("RolledBack"),"Retained incomplete backup; run its Rollback before reinstalling")
            for _,r in ipairs(H.records(oldBackup,manifest)) do
                assert(r.object and H.normal(H.source(r.object))==H.normal(r.new),"Stage 14 live source changed: "..r.item.key)
            end
            print("Stage 14 already installed; retained exact original backup");return true
        end
        local plan={}
        for _,item in ipairs(manifest.items) do
            local o,parent,name=H.resolve(item.key,true)
            local src=install.Sources:FindFirstChild(item.key)
            local payload=src and H.source(src)
            if item.server then
                assert(o and o.ClassName=="Script","NR2003Server missing")
                local old=H.source(o)
                assert(old:find("CupChassisAdapter",1,true) and old:find("PreSimulation",1,true),"Unsupported server controller")
                payload=manifest.serverPrefix..old
            else
                assert(payload and H.matches(payload,item.new),"Invalid payload: "..item.key)
                if item.old then assert(o and o.ClassName==item.class and H.matches(H.source(o),item.old),"V6 source differs: "..item.key)
                else assert(not o,"New module already exists: "..item.key) end
            end
            plan[#plan+1]={item=item,object=o,parent=parent,name=name,new=payload,old=o and H.source(o)}
        end
        for _,dep in ipairs(manifest.dependencies) do
            local o=H.resolve(dep.key,true);local accepted=false
            if o and o.ClassName==dep.class then
                for _,h in ipairs(dep.accepted) do if H.matches(H.source(o),h) then accepted=true;break end end
            end
            assert(accepted,"V6 dependency differs: "..dep.key)
        end
        local backup=Instance.new("Folder");backup.Name=H.BACKUP
        backup:SetAttribute("Bundle",manifest.bundle);backup:SetAttribute("PreviousStage14",pkg:GetAttribute("NR2003Stage14"))
        local records=Instance.new("Folder");records.Name="Records";records.Parent=backup
        for _,r in ipairs(plan) do
            local e=Instance.new("Folder");e.Name=r.item.key;e.Parent=records;r.record=e
            local ref=Instance.new("ObjectValue");ref.Name="Target";ref.Value=r.object;ref.Parent=e
            local installed=Instance.new("ModuleScript");installed.Name="Installed";installed.Source=r.new;installed.Parent=e
            local h=H.fingerprint(r.new);e:SetAttribute("NewBytes",h.bytes);e:SetAttribute("NewHash",h.fnv32)
            if r.old then
                local original=Instance.new("ModuleScript");original.Name="Original";original.Source=r.old;original.Parent=e
                h=H.fingerprint(r.old);e:SetAttribute("OldBytes",h.bytes);e:SetAttribute("OldHash",h.fnv32)
            end
        end
        for _,name in ipairs({"Support","Manifest","Rollback"}) do install[name]:Clone().Parent=backup end
        backup.Parent=game:GetService("ServerStorage")
        local ok,err=pcall(function()
            for _,r in ipairs(plan) do
                if not r.object then
                    r.object=Instance.new(r.item.class);r.object.Name=r.name
                    r.record.Target.Value=r.object;r.object.Parent=r.parent
                end
                H.write(r.object,r.new,r.old or "")
            end
            -- Pure protocol/codec smoke test in an isolated module graph (fresh require cache).
            local scratch=Instance.new("Folder");scratch.Name="Stage14SelfTest";scratch.Parent=backup
            local smoke=table.pack(pcall(function()
                for _,name in ipairs({"Stage14SelfTest","PredictionConfig","PredictionCheckpoint","PredictionProtocol","PredictionSession"}) do pkg.Roblox[name]:Clone().Parent=scratch end
                assert(require(scratch.Stage14SelfTest).run(),"Stage 14 smoke test failed")
            end))
            scratch:Destroy();assert(smoke[1],tostring(smoke[2]))
            pkg:SetAttribute("NR2003Stage14",manifest.bundle);backup:SetAttribute("Complete",true)
        end)
        if not ok then
            local restored,why=pcall(H.restore,backup,manifest,true)
            error("Stage 14 install failed: "..tostring(err)..(restored and "; original sources restored" or "; backup retained; rollback recovery failed: "..tostring(why)))
        end
        print("Stage 14 installed. Local NR2003 simulation + asynchronous server validation. Backup: ServerStorage."..H.BACKUP)
        return true
    end)
end
