--!native
--!optimize 2
-- GENERATED NR2003 Cup vehicle runtime: translated JIT callbacks, part 3 (tire0, tire1, tire2, tire3, forces).
-- These are the x87 callbacks NR2003.exe generates itself at car build (005b3090, mode-2 emitter),
-- translated instruction by instruction. Float32 stores round toward -inf (CW 0x077f).
-- Do not edit by hand: regenerate with recovery/stage6_7/gen_runtime.py.
return function(ctx)
local M, JIT, LKF, LKU, NB, NC = ctx.M, ctx.JIT, ctx.LKF, ctx.LKU, ctx.NB, ctx.NC
local rf, wf, ru, wu = buffer.readf32, buffer.writef32, buffer.readu32, buffer.writeu32
local abs, sqrt, sin, cos, fmod = math.abs, math.sqrt, math.sin, math.cos, math.fmod
local TINY = 2 ^ -125
local S = buffer.create(8)
local function fd(x)
	wf(S, 0, x)
	local r = rf(S, 0)
	if r > x then
		local u = ru(S, 0)
		if r > 0 then wu(S, 0, u - 1) elseif r == 0 then wu(S, 0, 0x80000001) else wu(S, 0, u + 1) end
		r = rf(S, 0)
	end
	return r
end
local function wfd(o, x)
	wf(M, o, x)
	local r = rf(M, o)
	if r > x then
		local u = ru(M, o)
		if r > 0 then wu(M, o, u - 1) elseif r == 0 then wu(M, o, 0x80000001) else wu(M, o, u + 1) end
	end
end

do -- tire0 (2 chunks)
  local r_eax, r_ebx, r_ecx, r_edx, r_esi, r_edi
  local function C1()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8212504)
    f1 = f1 * rf(M, 8204212)
    wfd(8210432, f1)
    f1 = sin(f1)
    wfd(8210484, f1)
    f1 = f1 * rf(M, 8212884)
    f2 = rf(M, 8210432)
    f2 = cos(f2)
    f3 = rf(M, 8212504)
    f3 = f3 * rf(M, 8204228)
    f3 = f3 + rf(M, 8204152)
    wfd(8210432, f3)
    f3 = cos(f3)
    f2 = f2 * f3
    wfd(8210316, f2)
    f2 = f2 * rf(M, 8212888)
    f1 = f1 + f2
    f2 = rf(M, 8210432)
    f2 = sin(f2)
    wfd(8210432, f2)
    f2 = f2 * rf(M, 8212892)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8204284)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212896)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8212900)
    f2 = f2 + f3
    f3 = rf(M, 8210432)
    f3 = f3 * rf(M, 8212904)
    f2 = f2 + f3
    wfd(8210324, f2)
    f2 = f2 * rf(M, 8204280)
    f1 = f1 - f2
    wfd(8210320, f1)
    f1 = f1 * f1
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8212872)
    f4 = rf(M, 8210316)
    f4 = f4 * rf(M, 8212876)
    f3 = f3 + f4
    f4 = rf(M, 8210432)
    f4 = f4 * rf(M, 8212880)
    f3 = f3 + f4
    wfd(8210432, f3)
    f3 = f3 * rf(M, 8204284)
    f2 = f2 - f3
    wfd(8210316, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8204280)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8204276)
    f2 = f2 - f3
    wfd(8210484, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f1 = sqrt(f1)
    q = fd(f1)
    if q < TINY and q > -TINY then f1 = 1 else f1 = 1 / q end
    wfd(8210292, f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8210292)
    wfd(8210320, f1)
    f1 = rf(M, 8210316)
    f1 = f1 * rf(M, 8210292)
    wfd(8210316, f1)
    f1 = rf(M, 8210484)
    f1 = f1 * rf(M, 8210292)
    wfd(8210292, f1)
    f1 = rf(M, 8212764)
    f1 = f1 * rf(M, 8204244)
    p1 = fd(f1)
    f1 = rf(M, 8204276)
    f1 = f1 * rf(M, 8212920)
    f2 = rf(M, 8204280)
    f2 = f2 * rf(M, 8212924)
    f1 = f1 + f2
    f2 = rf(M, 8204284)
    f2 = f2 * rf(M, 8212928)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204288)
    wfd(8210484, f1)
    f1 = rf(M, 8210292)
    f1 = f1 * rf(M, 8204280)
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8204284)
    f1 = f1 - f2
    wfd(8210288, f1)
    f1 = f1 * f1
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8204284)
    f3 = rf(M, 8210292)
    f3 = f3 * rf(M, 8204276)
    f2 = f2 - f3
    wfd(8210284, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210320)
    f3 = f3 * rf(M, 8204280)
    f2 = f2 - f3
    wfd(8210280, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f1 = sqrt(f1)
    q = fd(f1)
    if q < TINY and q > -TINY then f1 = 1 else f1 = 1 / q end
    wfd(8210456, f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8210456)
    wfd(8210288, f1)
    f1 = f1 * rf(M, 8210432)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8210456)
    wfd(8210284, f2)
    f2 = f2 * rf(M, 8210312)
    f1 = f1 + f2
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8210456)
    wfd(8210456, f2)
    f2 = f2 * rf(M, 8210324)
    f1 = f1 + f2
    wfd(8210280, f1)
    f1 = f1 * rf(M, 8218848)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8204280)
    f2 = f2 + f3
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8204284)
    f2 = f2 + f3
    wfd(8210324, f2)
    f2 = f2 * rf(M, 8218844)
    f2 = abs(f2)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = rf(M, 8210484) - f1
    f1 = fd(f1)
    if f1 > 0 or (f1 == 0 and 1 / f1 > 0) or f1 ~= f1 then f1 = 0 end
    wfd(8210432, f1)
    f1 = rf(M, 8210280)
    f1 = f1 * rf(M, 8204156)
    f1 = f1 * rf(M, 8210280)
    f1 = f1 + rf(M, 8210312)
    wfd(8210312, f1)
    f1 = rf(M, 8210484) - f1
    f1 = fd(f1)
    if f1 > 0 or (f1 == 0 and 1 / f1 > 0) or f1 ~= f1 then f1 = 0 end
    f1 = f1 - rf(M, 8210432)
    wfd(8210484, f1)
    f1 = rf(M, 8210312)
    f1 = -f1
    f1 = f1 - rf(M, 8210484)
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8204276)
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8218848)
    wfd(8210280, f2)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8210280)
    f1 = f1 + f2
    wfd(8210308, f1)
    f1 = f1 + rf(M, 8212920)
    wfd(8211740, f1)
    f1 = f1 - rf(M, 8204304)
    wfd(8211764, f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8211764)
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8204280)
    f3 = rf(M, 8210284)
    f3 = f3 * rf(M, 8210280)
    f2 = f2 + f3
    wfd(8210492, f2)
    f2 = f2 + rf(M, 8212924)
    wfd(8211744, f2)
    f2 = f2 - rf(M, 8204308)
    wfd(8211768, f2)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8211768)
    f1 = f1 + f2
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8204284)
    f3 = rf(M, 8210456)
    f3 = f3 * rf(M, 8210280)
    f2 = f2 + f3
    wfd(8210280, f2)
    f2 = f2 + rf(M, 8212928)
    wfd(8211748, f2)
    f2 = f2 - rf(M, 8204312)
    wfd(8211772, f2)
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8211772)
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8211764)
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8211768)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8211772)
    f1 = f1 + f2
    f2 = rf(M, 8218856)
    f2 = f2 * rf(M, 8212868)
    wfd(8210312, f2)
    f2 = f2 * rf(M, 8218136)
    f1 = f1 - f2
    p3 = fd(f1)
    p4 = ru(M, 8210324)
    p5 = ru(M, 8210432)
    p6 = ru(M, 8210484)
    p7 = ru(M, 8210312)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8212880)
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8212892)
    f1 = f1 + f2
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8212904)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8212860)
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8212876)
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8212888)
    f2 = f2 + f3
    f3 = rf(M, 8210280)
    f3 = f3 * rf(M, 8212900)
    f2 = f2 + f3
    wfd(8210484, f2)
    f2 = f2 * rf(M, 8212864)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8212996)
    wfd(8210432, f1)
    f1 = f1 * rf(M, 8212872)
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8212872)
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8212884)
    f2 = f2 + f3
    f3 = rf(M, 8210280)
    f3 = f3 * rf(M, 8212896)
    f2 = f2 + f3
    wfd(8210280, f2)
    f2 = f2 * rf(M, 8212864)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8212856)
    f2 = f2 - f3
    f2 = f2 + rf(M, 8213000)
    wfd(8210492, f2)
    f2 = f2 * rf(M, 8212876)
    f1 = f1 + f2
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212856)
    f3 = rf(M, 8210280)
    f3 = f3 * rf(M, 8212860)
    f2 = f2 - f3
    f2 = f2 + rf(M, 8213004)
    wfd(8210308, f2)
    f2 = f2 * rf(M, 8212880)
    f1 = f1 + f2
    f1 = f1 - rf(M, 8204292)
    wfd(8211752, f1)
    f1 = f1 * rf(M, 8204276)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8212884)
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8212888)
    f2 = f2 + f3
    f3 = rf(M, 8210308)
    f3 = f3 * rf(M, 8212892)
    f2 = f2 + f3
    f2 = f2 - rf(M, 8204296)
    wfd(8211756, f2)
    f2 = f2 * rf(M, 8204280)
    f1 = f1 + f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8212896)
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8212900)
    f2 = f2 + f3
    f3 = rf(M, 8210308)
    f3 = f3 * rf(M, 8212904)
    f2 = f2 + f3
    f2 = f2 - rf(M, 8204300)
    wfd(8211760, f2)
    f2 = f2 * rf(M, 8204284)
    f1 = f1 + f2
    p8 = fd(f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8211752)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8211756)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8211760)
    f1 = f1 + f2
    p9 = fd(f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8211752)
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8211756)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8211760)
    f1 = f1 + f2
    p10 = fd(f1)
    do local sp = NB(14); wu(M, sp + -7245816, 15453292); wu(M, sp + -7245812, 15453296); wu(M, sp + -7245808, 15453300); wu(M, sp + -7245804, 15453304); wf(M, sp + -7245800, p10); wf(M, sp + -7245796, p9); wf(M, sp + -7245792, p8); wu(M, sp + -7245788, p7); wu(M, sp + -7245784, p6); wu(M, sp + -7245780, p5); wu(M, sp + -7245776, p4); wf(M, sp + -7245772, p3); wf(M, sp + -7245768, p2); wf(M, sp + -7245764, p1); NC(0x55d880, 14) end
  end
  local function C2()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8207472)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8207476)
    f1 = f1 + f2
    f2 = rf(M, 8204276)
    f2 = f2 * rf(M, 8207480)
    f1 = f1 + f2
    wfd(8210288, f1)
    f1 = f1 * rf(M, 8212880)
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8207472)
    f3 = rf(M, 8210284)
    f3 = f3 * rf(M, 8207476)
    f2 = f2 + f3
    f3 = rf(M, 8204280)
    f3 = f3 * rf(M, 8207480)
    f2 = f2 + f3
    wfd(8210284, f2)
    f2 = f2 * rf(M, 8212892)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8207472)
    f3 = rf(M, 8210456)
    f3 = f3 * rf(M, 8207476)
    f2 = f2 + f3
    f3 = rf(M, 8204284)
    f3 = f3 * rf(M, 8207480)
    f2 = f2 + f3
    wfd(8210456, f2)
    f2 = f2 * rf(M, 8212904)
    f1 = f1 + f2
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8207468)
    wfd(8210320, f2)
    f2 = f2 * rf(M, 8212880)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8207468)
    wfd(8210316, f3)
    f3 = f3 * rf(M, 8212892)
    f2 = f2 + f3
    f3 = rf(M, 8210292)
    f3 = f3 * rf(M, 8207468)
    wfd(8210308, f3)
    f3 = f3 * rf(M, 8212904)
    f2 = f2 + f3
    f1 = f1 + f2
    p1 = fd(f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8212876)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8212888)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8212900)
    f1 = f1 + f2
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8212876)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8212888)
    f2 = f2 + f3
    f3 = rf(M, 8210308)
    f3 = f3 * rf(M, 8212900)
    f2 = f2 + f3
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8212872)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8212884)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8212896)
    f1 = f1 + f2
    p3 = fd(f1)
    do local sp = NB(6); wu(M, sp + -7245816, 15453320); wu(M, sp + -7245812, 15453324); wu(M, sp + -7245808, 15453328); wf(M, sp + -7245804, p3); wf(M, sp + -7245800, p2); wf(M, sp + -7245796, p1); NC(0x55e160, 6) end
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8212872)
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8212884)
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8212896)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207496)
    wfd(8210308, f1)
    f1 = f1 + rf(M, 8214820)
    wfd(8214820, f1)
    f1 = rf(M, 8207500)
    f1 = f1 + rf(M, 8214824)
    wfd(8214824, f1)
    f1 = rf(M, 8207504)
    f1 = f1 + rf(M, 8214828)
    wfd(8214828, f1)
    f1 = rf(M, 8210484)
    f1 = f1 * rf(M, 8207504)
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8207500)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214832)
    wfd(8214832, f1)
    f1 = rf(M, 8210312)
    f1 = f1 * rf(M, 8207496)
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8207504)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214836)
    wfd(8214836, f1)
    f1 = rf(M, 8210280)
    f1 = f1 * rf(M, 8207500)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8207496)
    f1 = f1 - f2
    wfd(8210280, f1)
    f1 = f1 + rf(M, 8214840)
    wfd(8214840, f1)
    p1 = ru(M, 8210280)
    p2 = ru(M, 8207480)
    p3 = ru(M, 8207476)
    do local sp = NB(3); wu(M, sp + -7245816, p3); wu(M, sp + -7245812, p2); wu(M, sp + -7245808, p1); NC(0x55e180, 3) end
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8212872)
    f2 = rf(M, 8207500)
    f2 = f2 * rf(M, 8212876)
    f1 = f1 + f2
    f2 = rf(M, 8207504)
    f2 = f2 * rf(M, 8212880)
    f1 = f1 + f2
    wfd(8211728, f1)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8212884)
    f2 = rf(M, 8207500)
    f2 = f2 * rf(M, 8212888)
    f1 = f1 + f2
    f2 = rf(M, 8207504)
    f2 = f2 * rf(M, 8212892)
    f1 = f1 + f2
    wfd(8211732, f1)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8212896)
    f2 = rf(M, 8207500)
    f2 = f2 * rf(M, 8212900)
    f1 = f1 + f2
    f2 = rf(M, 8207504)
    f2 = f2 * rf(M, 8212904)
    f1 = f1 + f2
    wfd(8211736, f1)
  end
  JIT[0xeb4399] = function() -- tire0
    C1()
    C2()
  end
end
do -- tire1 (2 chunks)
  local r_eax, r_ebx, r_ecx, r_edx, r_esi, r_edi
  local function C1()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8213024)
    f1 = f1 * rf(M, 8204216)
    wfd(8210308, f1)
    f1 = sin(f1)
    wfd(8210280, f1)
    f1 = f1 * rf(M, 8213404)
    f2 = rf(M, 8210308)
    f2 = cos(f2)
    f3 = rf(M, 8213024)
    f3 = f3 * rf(M, 8204232)
    f3 = f3 + rf(M, 8204160)
    wfd(8210308, f3)
    f3 = cos(f3)
    f2 = f2 * f3
    wfd(8210484, f2)
    f2 = f2 * rf(M, 8213408)
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = sin(f2)
    wfd(8210308, f2)
    f2 = f2 * rf(M, 8213412)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8204284)
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8213416)
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8213420)
    f2 = f2 + f3
    f3 = rf(M, 8210308)
    f3 = f3 * rf(M, 8213424)
    f2 = f2 + f3
    wfd(8210316, f2)
    f2 = f2 * rf(M, 8204280)
    f1 = f1 - f2
    wfd(8210320, f1)
    f1 = f1 * f1
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210280)
    f3 = f3 * rf(M, 8213392)
    f4 = rf(M, 8210484)
    f4 = f4 * rf(M, 8213396)
    f3 = f3 + f4
    f4 = rf(M, 8210308)
    f4 = f4 * rf(M, 8213400)
    f3 = f3 + f4
    wfd(8210308, f3)
    f3 = f3 * rf(M, 8204284)
    f2 = f2 - f3
    wfd(8210484, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8204280)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8204276)
    f2 = f2 - f3
    wfd(8210280, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f1 = sqrt(f1)
    q = fd(f1)
    if q < TINY and q > -TINY then f1 = 1 else f1 = 1 / q end
    wfd(8210456, f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8210456)
    wfd(8210320, f1)
    f1 = rf(M, 8210484)
    f1 = f1 * rf(M, 8210456)
    wfd(8210484, f1)
    f1 = rf(M, 8210280)
    f1 = f1 * rf(M, 8210456)
    wfd(8210456, f1)
    f1 = rf(M, 8213284)
    f1 = f1 * rf(M, 8204248)
    p1 = fd(f1)
    f1 = rf(M, 8204276)
    f1 = f1 * rf(M, 8213440)
    f2 = rf(M, 8204280)
    f2 = f2 * rf(M, 8213444)
    f1 = f1 + f2
    f2 = rf(M, 8204284)
    f2 = f2 * rf(M, 8213448)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204288)
    wfd(8210280, f1)
    f1 = rf(M, 8210456)
    f1 = f1 * rf(M, 8204280)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8204284)
    f1 = f1 - f2
    wfd(8210284, f1)
    f1 = f1 * f1
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8204284)
    f3 = rf(M, 8210456)
    f3 = f3 * rf(M, 8204276)
    f2 = f2 - f3
    wfd(8210288, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210320)
    f3 = f3 * rf(M, 8204280)
    f2 = f2 - f3
    wfd(8210292, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f1 = sqrt(f1)
    q = fd(f1)
    if q < TINY and q > -TINY then f1 = 1 else f1 = 1 / q end
    wfd(8210492, f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8210492)
    wfd(8210284, f1)
    f1 = f1 * rf(M, 8210308)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8210492)
    wfd(8210288, f2)
    f2 = f2 * rf(M, 8210312)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8210492)
    wfd(8210492, f2)
    f2 = f2 * rf(M, 8210316)
    f1 = f1 + f2
    wfd(8210292, f1)
    f1 = f1 * rf(M, 8218852)
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8204280)
    f2 = f2 + f3
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8204284)
    f2 = f2 + f3
    wfd(8210316, f2)
    f2 = f2 * rf(M, 8218844)
    f2 = abs(f2)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = rf(M, 8210280) - f1
    f1 = fd(f1)
    if f1 > 0 or (f1 == 0 and 1 / f1 > 0) or f1 ~= f1 then f1 = 0 end
    wfd(8210308, f1)
    f1 = rf(M, 8210292)
    f1 = f1 * rf(M, 8204164)
    f1 = f1 * rf(M, 8210292)
    f1 = f1 + rf(M, 8210312)
    wfd(8210312, f1)
    f1 = rf(M, 8210280) - f1
    f1 = fd(f1)
    if f1 > 0 or (f1 == 0 and 1 / f1 > 0) or f1 ~= f1 then f1 = 0 end
    f1 = f1 - rf(M, 8210308)
    wfd(8210280, f1)
    f1 = rf(M, 8210312)
    f1 = -f1
    f1 = f1 - rf(M, 8210280)
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8204276)
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8218852)
    wfd(8210292, f2)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8210292)
    f1 = f1 + f2
    wfd(8210432, f1)
    f1 = f1 + rf(M, 8213440)
    wfd(8211740, f1)
    f1 = f1 - rf(M, 8204304)
    wfd(8211764, f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8211764)
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8204280)
    f3 = rf(M, 8210288)
    f3 = f3 * rf(M, 8210292)
    f2 = f2 + f3
    wfd(8210324, f2)
    f2 = f2 + rf(M, 8213444)
    wfd(8211744, f2)
    f2 = f2 - rf(M, 8204308)
    wfd(8211768, f2)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8211768)
    f1 = f1 + f2
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8204284)
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8210292)
    f2 = f2 + f3
    wfd(8210292, f2)
    f2 = f2 + rf(M, 8213448)
    wfd(8211748, f2)
    f2 = f2 - rf(M, 8204312)
    wfd(8211772, f2)
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8211772)
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8211764)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8211768)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8211772)
    f1 = f1 + f2
    f2 = rf(M, 8218860)
    f2 = f2 * rf(M, 8213388)
    wfd(8210312, f2)
    f2 = f2 * rf(M, 8218136)
    f1 = f1 - f2
    p3 = fd(f1)
    p4 = ru(M, 8210316)
    p5 = ru(M, 8210308)
    p6 = ru(M, 8210280)
    p7 = ru(M, 8210312)
    f1 = rf(M, 8210432)
    f1 = f1 * rf(M, 8213400)
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8213412)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213424)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8213380)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213396)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8213408)
    f2 = f2 + f3
    f3 = rf(M, 8210292)
    f3 = f3 * rf(M, 8213420)
    f2 = f2 + f3
    wfd(8210280, f2)
    f2 = f2 * rf(M, 8213384)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8213516)
    wfd(8210308, f1)
    f1 = f1 * rf(M, 8213392)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213392)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8213404)
    f2 = f2 + f3
    f3 = rf(M, 8210292)
    f3 = f3 * rf(M, 8213416)
    f2 = f2 + f3
    wfd(8210292, f2)
    f2 = f2 * rf(M, 8213384)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8213376)
    f2 = f2 - f3
    f2 = f2 + rf(M, 8213520)
    wfd(8210324, f2)
    f2 = f2 * rf(M, 8213396)
    f1 = f1 + f2
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8213376)
    f3 = rf(M, 8210292)
    f3 = f3 * rf(M, 8213380)
    f2 = f2 - f3
    f2 = f2 + rf(M, 8213524)
    wfd(8210432, f2)
    f2 = f2 * rf(M, 8213400)
    f1 = f1 + f2
    f1 = f1 - rf(M, 8204292)
    wfd(8211752, f1)
    f1 = f1 * rf(M, 8204276)
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213404)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8213408)
    f2 = f2 + f3
    f3 = rf(M, 8210432)
    f3 = f3 * rf(M, 8213412)
    f2 = f2 + f3
    f2 = f2 - rf(M, 8204296)
    wfd(8211756, f2)
    f2 = f2 * rf(M, 8204280)
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213416)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8213420)
    f2 = f2 + f3
    f3 = rf(M, 8210432)
    f3 = f3 * rf(M, 8213424)
    f2 = f2 + f3
    f2 = f2 - rf(M, 8204300)
    wfd(8211760, f2)
    f2 = f2 * rf(M, 8204284)
    f1 = f1 + f2
    p8 = fd(f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8211752)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8211756)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8211760)
    f1 = f1 + f2
    p9 = fd(f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8211752)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8211756)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8211760)
    f1 = f1 + f2
    p10 = fd(f1)
    do local sp = NB(14); wu(M, sp + -7245816, 15453412); wu(M, sp + -7245812, 15453416); wu(M, sp + -7245808, 15453420); wu(M, sp + -7245804, 15453424); wf(M, sp + -7245800, p10); wf(M, sp + -7245796, p9); wf(M, sp + -7245792, p8); wu(M, sp + -7245788, p7); wu(M, sp + -7245784, p6); wu(M, sp + -7245780, p5); wu(M, sp + -7245776, p4); wf(M, sp + -7245772, p3); wf(M, sp + -7245768, p2); wf(M, sp + -7245764, p1); NC(0x55d8d0, 14) end
  end
  local function C2()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8207592)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8207596)
    f1 = f1 + f2
    f2 = rf(M, 8204276)
    f2 = f2 * rf(M, 8207600)
    f1 = f1 + f2
    wfd(8210284, f1)
    f1 = f1 * rf(M, 8213400)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8207592)
    f3 = rf(M, 8210288)
    f3 = f3 * rf(M, 8207596)
    f2 = f2 + f3
    f3 = rf(M, 8204280)
    f3 = f3 * rf(M, 8207600)
    f2 = f2 + f3
    wfd(8210288, f2)
    f2 = f2 * rf(M, 8213412)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8207592)
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8207596)
    f2 = f2 + f3
    f3 = rf(M, 8204284)
    f3 = f3 * rf(M, 8207600)
    f2 = f2 + f3
    wfd(8210492, f2)
    f2 = f2 * rf(M, 8213424)
    f1 = f1 + f2
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8207588)
    wfd(8210320, f2)
    f2 = f2 * rf(M, 8213400)
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8207588)
    wfd(8210484, f3)
    f3 = f3 * rf(M, 8213412)
    f2 = f2 + f3
    f3 = rf(M, 8210456)
    f3 = f3 * rf(M, 8207588)
    wfd(8210432, f3)
    f3 = f3 * rf(M, 8213424)
    f2 = f2 + f3
    f1 = f1 + f2
    p1 = fd(f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8213396)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8213408)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8213420)
    f1 = f1 + f2
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8213396)
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8213408)
    f2 = f2 + f3
    f3 = rf(M, 8210432)
    f3 = f3 * rf(M, 8213420)
    f2 = f2 + f3
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8213392)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8213404)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8213416)
    f1 = f1 + f2
    p3 = fd(f1)
    do local sp = NB(6); wu(M, sp + -7245816, 15453440); wu(M, sp + -7245812, 15453444); wu(M, sp + -7245808, 15453448); wf(M, sp + -7245804, p3); wf(M, sp + -7245800, p2); wf(M, sp + -7245796, p1); NC(0x55e160, 6) end
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8213392)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8213404)
    f1 = f1 + f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213416)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207616)
    wfd(8210432, f1)
    f1 = f1 + rf(M, 8214844)
    wfd(8214844, f1)
    f1 = rf(M, 8207620)
    f1 = f1 + rf(M, 8214848)
    wfd(8214848, f1)
    f1 = rf(M, 8207624)
    f1 = f1 + rf(M, 8214852)
    wfd(8214852, f1)
    f1 = rf(M, 8210280)
    f1 = f1 * rf(M, 8207624)
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8207620)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214856)
    wfd(8214856, f1)
    f1 = rf(M, 8210312)
    f1 = f1 * rf(M, 8207616)
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8207624)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214860)
    wfd(8214860, f1)
    f1 = rf(M, 8210292)
    f1 = f1 * rf(M, 8207620)
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8207616)
    f1 = f1 - f2
    wfd(8210292, f1)
    f1 = f1 + rf(M, 8214864)
    wfd(8214864, f1)
    p1 = ru(M, 8210292)
    p2 = ru(M, 8207600)
    p3 = ru(M, 8207596)
    do local sp = NB(3); wu(M, sp + -7245816, p3); wu(M, sp + -7245812, p2); wu(M, sp + -7245808, p1); NC(0x55e180, 3) end
    f1 = rf(M, 8210432)
    f1 = f1 * rf(M, 8213392)
    f2 = rf(M, 8207620)
    f2 = f2 * rf(M, 8213396)
    f1 = f1 + f2
    f2 = rf(M, 8207624)
    f2 = f2 * rf(M, 8213400)
    f1 = f1 + f2
    wfd(8211728, f1)
    f1 = rf(M, 8210432)
    f1 = f1 * rf(M, 8213404)
    f2 = rf(M, 8207620)
    f2 = f2 * rf(M, 8213408)
    f1 = f1 + f2
    f2 = rf(M, 8207624)
    f2 = f2 * rf(M, 8213412)
    f1 = f1 + f2
    wfd(8211732, f1)
    f1 = rf(M, 8210432)
    f1 = f1 * rf(M, 8213416)
    f2 = rf(M, 8207620)
    f2 = f2 * rf(M, 8213420)
    f1 = f1 + f2
    f2 = rf(M, 8207624)
    f2 = f2 * rf(M, 8213424)
    f1 = f1 + f2
    wfd(8211736, f1)
  end
  JIT[0xeb4982] = function() -- tire1
    C1()
    C2()
  end
end
do -- tire2 (2 chunks)
  local r_eax, r_ebx, r_ecx, r_edx, r_esi, r_edi
  local function C1()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8213548)
    f1 = f1 * rf(M, 8204140)
    f2 = rf(M, 8213612)
    f2 = f2 * rf(M, 8204144)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204148)
    wfd(8210432, f1)
    f1 = sin(f1)
    wfd(8210292, f1)
    f1 = f1 * rf(M, 8213804)
    f2 = rf(M, 8210432)
    f2 = cos(f2)
    f3 = rf(M, 8204168)
    f3 = cos(f3)
    f2 = f2 * f3
    wfd(8210432, f2)
    f2 = f2 * rf(M, 8213808)
    f1 = f1 + f2
    f2 = rf(M, 8204168)
    f2 = sin(f2)
    wfd(8210280, f2)
    f2 = f2 * rf(M, 8213812)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8204284)
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213816)
    f3 = rf(M, 8210432)
    f3 = f3 * rf(M, 8213820)
    f2 = f2 + f3
    f3 = rf(M, 8210280)
    f3 = f3 * rf(M, 8213824)
    f2 = f2 + f3
    wfd(8210484, f2)
    f2 = f2 * rf(M, 8204280)
    f1 = f1 - f2
    wfd(8210320, f1)
    f1 = f1 * f1
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210292)
    f3 = f3 * rf(M, 8213792)
    f4 = rf(M, 8210432)
    f4 = f4 * rf(M, 8213796)
    f3 = f3 + f4
    f4 = rf(M, 8210280)
    f4 = f4 * rf(M, 8213800)
    f3 = f3 + f4
    wfd(8210280, f3)
    f3 = f3 * rf(M, 8204284)
    f2 = f2 - f3
    wfd(8210432, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8204280)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8204276)
    f2 = f2 - f3
    wfd(8210292, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f1 = sqrt(f1)
    q = fd(f1)
    if q < TINY and q > -TINY then f1 = 1 else f1 = 1 / q end
    wfd(8210492, f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8210492)
    wfd(8210320, f1)
    f1 = rf(M, 8210432)
    f1 = f1 * rf(M, 8210492)
    wfd(8210432, f1)
    f1 = rf(M, 8210292)
    f1 = f1 * rf(M, 8210492)
    wfd(8210492, f1)
    p1 = ru(M, 8204740)
    f1 = rf(M, 8204276)
    f1 = f1 * rf(M, 8213840)
    f2 = rf(M, 8204280)
    f2 = f2 * rf(M, 8213844)
    f1 = f1 + f2
    f2 = rf(M, 8204284)
    f2 = f2 * rf(M, 8213848)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204288)
    wfd(8210292, f1)
    f1 = rf(M, 8210492)
    f1 = f1 * rf(M, 8204280)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8204284)
    f1 = f1 - f2
    wfd(8210288, f1)
    f1 = f1 * f1
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8204284)
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8204276)
    f2 = f2 - f3
    wfd(8210284, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210320)
    f3 = f3 * rf(M, 8204280)
    f2 = f2 - f3
    wfd(8210456, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f1 = sqrt(f1)
    q = fd(f1)
    if q < TINY and q > -TINY then f1 = 1 else f1 = 1 / q end
    wfd(8210324, f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8210324)
    wfd(8210288, f1)
    f1 = f1 * rf(M, 8210280)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8210324)
    wfd(8210284, f2)
    f2 = f2 * rf(M, 8210312)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8210324)
    wfd(8210324, f2)
    f2 = f2 * rf(M, 8210484)
    f1 = f1 + f2
    wfd(8210456, f1)
    f1 = f1 * rf(M, 8218852)
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8204280)
    f2 = f2 + f3
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8204284)
    f2 = f2 + f3
    wfd(8210484, f2)
    f2 = f2 * rf(M, 8218844)
    f2 = abs(f2)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = rf(M, 8210292) - f1
    f1 = fd(f1)
    if f1 > 0 or (f1 == 0 and 1 / f1 > 0) or f1 ~= f1 then f1 = 0 end
    wfd(8210280, f1)
    f1 = rf(M, 8210456)
    f1 = f1 * rf(M, 8204172)
    f1 = f1 * rf(M, 8210456)
    f1 = f1 + rf(M, 8210312)
    wfd(8210312, f1)
    f1 = rf(M, 8210292) - f1
    f1 = fd(f1)
    if f1 > 0 or (f1 == 0 and 1 / f1 > 0) or f1 ~= f1 then f1 = 0 end
    f1 = f1 - rf(M, 8210280)
    wfd(8210292, f1)
    f1 = rf(M, 8210312)
    f1 = -f1
    f1 = f1 - rf(M, 8210292)
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8204276)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8218852)
    wfd(8210456, f2)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8210456)
    f1 = f1 + f2
    wfd(8210308, f1)
    f1 = f1 + rf(M, 8213840)
    wfd(8211740, f1)
    f1 = f1 - rf(M, 8204304)
    wfd(8211764, f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8211764)
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8204280)
    f3 = rf(M, 8210284)
    f3 = f3 * rf(M, 8210456)
    f2 = f2 + f3
    wfd(8210316, f2)
    f2 = f2 + rf(M, 8213844)
    wfd(8211744, f2)
    f2 = f2 - rf(M, 8204308)
    wfd(8211768, f2)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8211768)
    f1 = f1 + f2
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8204284)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8210456)
    f2 = f2 + f3
    wfd(8210456, f2)
    f2 = f2 + rf(M, 8213848)
    wfd(8211748, f2)
    f2 = f2 - rf(M, 8204312)
    wfd(8211772, f2)
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8211772)
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8211764)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8211768)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8211772)
    f1 = f1 + f2
    f2 = rf(M, 8218856)
    f2 = f2 * rf(M, 8213788)
    wfd(8210312, f2)
    f2 = f2 * rf(M, 8218136)
    f1 = f1 - f2
    p3 = fd(f1)
    p4 = ru(M, 8210484)
    p5 = ru(M, 8210280)
    p6 = ru(M, 8210292)
    p7 = ru(M, 8210312)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8213800)
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8213812)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8213824)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8213780)
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213796)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8213808)
    f2 = f2 + f3
    f3 = rf(M, 8210456)
    f3 = f3 * rf(M, 8213820)
    f2 = f2 + f3
    wfd(8210292, f2)
    f2 = f2 * rf(M, 8213784)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8213932)
    wfd(8210280, f1)
    f1 = f1 * rf(M, 8213792)
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213792)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8213804)
    f2 = f2 + f3
    f3 = rf(M, 8210456)
    f3 = f3 * rf(M, 8213816)
    f2 = f2 + f3
    wfd(8210456, f2)
    f2 = f2 * rf(M, 8213784)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8213776)
    f2 = f2 - f3
    f2 = f2 + rf(M, 8213936)
    wfd(8210316, f2)
    f2 = f2 * rf(M, 8213796)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213776)
    f3 = rf(M, 8210456)
    f3 = f3 * rf(M, 8213780)
    f2 = f2 - f3
    f2 = f2 + rf(M, 8213940)
    wfd(8210308, f2)
    f2 = f2 * rf(M, 8213800)
    f1 = f1 + f2
    f1 = f1 - rf(M, 8204292)
    wfd(8211752, f1)
    f1 = f1 * rf(M, 8204276)
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8213804)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8213808)
    f2 = f2 + f3
    f3 = rf(M, 8210308)
    f3 = f3 * rf(M, 8213812)
    f2 = f2 + f3
    f2 = f2 - rf(M, 8204296)
    wfd(8211756, f2)
    f2 = f2 * rf(M, 8204280)
    f1 = f1 + f2
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8213816)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8213820)
    f2 = f2 + f3
    f3 = rf(M, 8210308)
    f3 = f3 * rf(M, 8213824)
    f2 = f2 + f3
    f2 = f2 - rf(M, 8204300)
    wfd(8211760, f2)
    f2 = f2 * rf(M, 8204284)
    f1 = f1 + f2
    p8 = fd(f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8211752)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8211756)
    f1 = f1 + f2
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8211760)
    f1 = f1 + f2
    p9 = fd(f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8211752)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8211756)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8211760)
    f1 = f1 + f2
    p10 = fd(f1)
    do local sp = NB(14); wu(M, sp + -7245816, 15453532); wu(M, sp + -7245812, 15453536); wu(M, sp + -7245808, 15453540); wu(M, sp + -7245804, 15453544); wf(M, sp + -7245800, p10); wf(M, sp + -7245796, p9); wf(M, sp + -7245792, p8); wu(M, sp + -7245788, p7); wu(M, sp + -7245784, p6); wu(M, sp + -7245780, p5); wu(M, sp + -7245776, p4); wf(M, sp + -7245772, p3); wf(M, sp + -7245768, p2); wu(M, sp + -7245764, p1); NC(0x55d920, 14) end
  end
  local function C2()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8207712)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8207716)
    f1 = f1 + f2
    f2 = rf(M, 8204276)
    f2 = f2 * rf(M, 8207720)
    f1 = f1 + f2
    wfd(8210288, f1)
    f1 = f1 * rf(M, 8213800)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8207712)
    f3 = rf(M, 8210284)
    f3 = f3 * rf(M, 8207716)
    f2 = f2 + f3
    f3 = rf(M, 8204280)
    f3 = f3 * rf(M, 8207720)
    f2 = f2 + f3
    wfd(8210284, f2)
    f2 = f2 * rf(M, 8213812)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8207712)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8207716)
    f2 = f2 + f3
    f3 = rf(M, 8204284)
    f3 = f3 * rf(M, 8207720)
    f2 = f2 + f3
    wfd(8210308, f2)
    f2 = f2 * rf(M, 8213824)
    f1 = f1 + f2
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8207708)
    wfd(8210320, f2)
    f2 = f2 * rf(M, 8213800)
    f3 = rf(M, 8210432)
    f3 = f3 * rf(M, 8207708)
    wfd(8210432, f3)
    f3 = f3 * rf(M, 8213812)
    f2 = f2 + f3
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8207708)
    wfd(8210324, f3)
    f3 = f3 * rf(M, 8213824)
    f2 = f2 + f3
    f1 = f1 + f2
    p1 = fd(f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8213796)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8213808)
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213820)
    f1 = f1 + f2
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8213796)
    f3 = rf(M, 8210432)
    f3 = f3 * rf(M, 8213808)
    f2 = f2 + f3
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8213820)
    f2 = f2 + f3
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8210288)
    f1 = f1 * rf(M, 8213792)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8213804)
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213816)
    f1 = f1 + f2
    p3 = fd(f1)
    do local sp = NB(6); wu(M, sp + -7245816, 15453560); wu(M, sp + -7245812, 15453564); wu(M, sp + -7245808, 15453568); wf(M, sp + -7245804, p3); wf(M, sp + -7245800, p2); wf(M, sp + -7245796, p1); NC(0x55e160, 6) end
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8213792)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213804)
    f1 = f1 + f2
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8213816)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207736)
    wfd(8210324, f1)
    f1 = f1 + rf(M, 8214868)
    wfd(8214868, f1)
    f1 = rf(M, 8207740)
    f1 = f1 + rf(M, 8214872)
    wfd(8214872, f1)
    f1 = rf(M, 8207744)
    f1 = f1 + rf(M, 8214876)
    wfd(8214876, f1)
    f1 = rf(M, 8210292)
    f1 = f1 * rf(M, 8207744)
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8207740)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214880)
    wfd(8214880, f1)
    f1 = rf(M, 8210312)
    f1 = f1 * rf(M, 8207736)
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8207744)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214884)
    wfd(8214884, f1)
    f1 = rf(M, 8210456)
    f1 = f1 * rf(M, 8207740)
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8207736)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214888)
    wfd(8214888, f1)
    f1 = rf(M, 8210324)
    f1 = f1 * rf(M, 8213792)
    f2 = rf(M, 8207740)
    f2 = f2 * rf(M, 8213796)
    f1 = f1 + f2
    f2 = rf(M, 8207744)
    f2 = f2 * rf(M, 8213800)
    f1 = f1 + f2
    wfd(8211728, f1)
    f1 = rf(M, 8210324)
    f1 = f1 * rf(M, 8213804)
    f2 = rf(M, 8207740)
    f2 = f2 * rf(M, 8213808)
    f1 = f1 + f2
    f2 = rf(M, 8207744)
    f2 = f2 * rf(M, 8213812)
    f1 = f1 + f2
    wfd(8211732, f1)
    f1 = rf(M, 8210324)
    f1 = f1 * rf(M, 8213816)
    f2 = rf(M, 8207740)
    f2 = f2 * rf(M, 8213820)
    f1 = f1 + f2
    f2 = rf(M, 8207744)
    f2 = f2 * rf(M, 8213824)
    f1 = f1 + f2
    wfd(8211736, f1)
  end
  JIT[0xeb4f6a] = function() -- tire2
    C1()
    C2()
  end
end
do -- tire3 (2 chunks)
  local r_eax, r_ebx, r_ecx, r_edx, r_esi, r_edi
  local function C1()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8213548)
    f1 = f1 * rf(M, 8204140)
    f2 = rf(M, 8213612)
    f2 = f2 * rf(M, 8204144)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204148)
    wfd(8210324, f1)
    f1 = sin(f1)
    wfd(8210456, f1)
    f1 = f1 * rf(M, 8213972)
    f2 = rf(M, 8210324)
    f2 = cos(f2)
    f3 = rf(M, 8204176)
    f3 = cos(f3)
    f2 = f2 * f3
    wfd(8210324, f2)
    f2 = f2 * rf(M, 8213976)
    f1 = f1 + f2
    f2 = rf(M, 8204176)
    f2 = sin(f2)
    wfd(8210292, f2)
    f2 = f2 * rf(M, 8213980)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8204284)
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8213984)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8213988)
    f2 = f2 + f3
    f3 = rf(M, 8210292)
    f3 = f3 * rf(M, 8213992)
    f2 = f2 + f3
    wfd(8210432, f2)
    f2 = f2 * rf(M, 8204280)
    f1 = f1 - f2
    wfd(8210320, f1)
    f1 = f1 * f1
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210456)
    f3 = f3 * rf(M, 8213960)
    f4 = rf(M, 8210324)
    f4 = f4 * rf(M, 8213964)
    f3 = f3 + f4
    f4 = rf(M, 8210292)
    f4 = f4 * rf(M, 8213968)
    f3 = f3 + f4
    wfd(8210292, f3)
    f3 = f3 * rf(M, 8204284)
    f2 = f2 - f3
    wfd(8210324, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8204280)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8204276)
    f2 = f2 - f3
    wfd(8210456, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f1 = sqrt(f1)
    q = fd(f1)
    if q < TINY and q > -TINY then f1 = 1 else f1 = 1 / q end
    wfd(8210308, f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8210308)
    wfd(8210320, f1)
    f1 = rf(M, 8210324)
    f1 = f1 * rf(M, 8210308)
    wfd(8210324, f1)
    f1 = rf(M, 8210456)
    f1 = f1 * rf(M, 8210308)
    wfd(8210308, f1)
    p1 = ru(M, 8204740)
    f1 = rf(M, 8204276)
    f1 = f1 * rf(M, 8214008)
    f2 = rf(M, 8204280)
    f2 = f2 * rf(M, 8214012)
    f1 = f1 + f2
    f2 = rf(M, 8204284)
    f2 = f2 * rf(M, 8214016)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204288)
    wfd(8210456, f1)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8204280)
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8204284)
    f1 = f1 - f2
    wfd(8210284, f1)
    f1 = f1 * f1
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8204284)
    f3 = rf(M, 8210308)
    f3 = f3 * rf(M, 8204276)
    f2 = f2 - f3
    wfd(8210288, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210320)
    f3 = f3 * rf(M, 8204280)
    f2 = f2 - f3
    wfd(8210492, f2)
    f2 = f2 * f2
    f1 = f1 + f2
    f1 = sqrt(f1)
    q = fd(f1)
    if q < TINY and q > -TINY then f1 = 1 else f1 = 1 / q end
    wfd(8210316, f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8210316)
    wfd(8210284, f1)
    f1 = f1 * rf(M, 8210292)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8210316)
    wfd(8210288, f2)
    f2 = f2 * rf(M, 8210312)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8210316)
    wfd(8210316, f2)
    f2 = f2 * rf(M, 8210432)
    f1 = f1 + f2
    wfd(8210492, f1)
    f1 = f1 * rf(M, 8218852)
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8204276)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8204280)
    f2 = f2 + f3
    f3 = rf(M, 8210432)
    f3 = f3 * rf(M, 8204284)
    f2 = f2 + f3
    wfd(8210432, f2)
    f2 = f2 * rf(M, 8218844)
    f2 = abs(f2)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = rf(M, 8210456) - f1
    f1 = fd(f1)
    if f1 > 0 or (f1 == 0 and 1 / f1 > 0) or f1 ~= f1 then f1 = 0 end
    wfd(8210292, f1)
    f1 = rf(M, 8210492)
    f1 = f1 * rf(M, 8204180)
    f1 = f1 * rf(M, 8210492)
    f1 = f1 + rf(M, 8210312)
    wfd(8210312, f1)
    f1 = rf(M, 8210456) - f1
    f1 = fd(f1)
    if f1 > 0 or (f1 == 0 and 1 / f1 > 0) or f1 ~= f1 then f1 = 0 end
    f1 = f1 - rf(M, 8210292)
    wfd(8210456, f1)
    f1 = rf(M, 8210312)
    f1 = -f1
    f1 = f1 - rf(M, 8210456)
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8204276)
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8218852)
    wfd(8210492, f2)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8210492)
    f1 = f1 + f2
    wfd(8210280, f1)
    f1 = f1 + rf(M, 8214008)
    wfd(8211740, f1)
    f1 = f1 - rf(M, 8204304)
    wfd(8211764, f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8211764)
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8204280)
    f3 = rf(M, 8210288)
    f3 = f3 * rf(M, 8210492)
    f2 = f2 + f3
    wfd(8210484, f2)
    f2 = f2 + rf(M, 8214012)
    wfd(8211744, f2)
    f2 = f2 - rf(M, 8204308)
    wfd(8211768, f2)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8211768)
    f1 = f1 + f2
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8204284)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8210492)
    f2 = f2 + f3
    wfd(8210492, f2)
    f2 = f2 + rf(M, 8214016)
    wfd(8211748, f2)
    f2 = f2 - rf(M, 8204312)
    wfd(8211772, f2)
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8211772)
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8211764)
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8211768)
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8211772)
    f1 = f1 + f2
    f2 = rf(M, 8218856)
    f2 = f2 * rf(M, 8213956)
    wfd(8210312, f2)
    f2 = f2 * rf(M, 8218136)
    f1 = f1 - f2
    p3 = fd(f1)
    p4 = ru(M, 8210432)
    p5 = ru(M, 8210292)
    p6 = ru(M, 8210456)
    p7 = ru(M, 8210312)
    f1 = rf(M, 8210280)
    f1 = f1 * rf(M, 8213968)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8213980)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8213992)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 * rf(M, 8213780)
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8213964)
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8213976)
    f2 = f2 + f3
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8213988)
    f2 = f2 + f3
    wfd(8210456, f2)
    f2 = f2 * rf(M, 8213784)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214100)
    wfd(8210292, f1)
    f1 = f1 * rf(M, 8213960)
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8213960)
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8213972)
    f2 = f2 + f3
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8213984)
    f2 = f2 + f3
    wfd(8210492, f2)
    f2 = f2 * rf(M, 8213784)
    f3 = rf(M, 8210312)
    f3 = f3 * rf(M, 8213776)
    f2 = f2 - f3
    f2 = f2 + rf(M, 8214104)
    wfd(8210484, f2)
    f2 = f2 * rf(M, 8213964)
    f1 = f1 + f2
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8213776)
    f3 = rf(M, 8210492)
    f3 = f3 * rf(M, 8213780)
    f2 = f2 - f3
    f2 = f2 + rf(M, 8214108)
    wfd(8210280, f2)
    f2 = f2 * rf(M, 8213968)
    f1 = f1 + f2
    f1 = f1 - rf(M, 8204292)
    wfd(8211752, f1)
    f1 = f1 * rf(M, 8204276)
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213972)
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8213976)
    f2 = f2 + f3
    f3 = rf(M, 8210280)
    f3 = f3 * rf(M, 8213980)
    f2 = f2 + f3
    f2 = f2 - rf(M, 8204296)
    wfd(8211756, f2)
    f2 = f2 * rf(M, 8204280)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213984)
    f3 = rf(M, 8210484)
    f3 = f3 * rf(M, 8213988)
    f2 = f2 + f3
    f3 = rf(M, 8210280)
    f3 = f3 * rf(M, 8213992)
    f2 = f2 + f3
    f2 = f2 - rf(M, 8204300)
    wfd(8211760, f2)
    f2 = f2 * rf(M, 8204284)
    f1 = f1 + f2
    p8 = fd(f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8211752)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8211756)
    f1 = f1 + f2
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8211760)
    f1 = f1 + f2
    p9 = fd(f1)
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8211752)
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8211756)
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8211760)
    f1 = f1 + f2
    p10 = fd(f1)
    do local sp = NB(14); wu(M, sp + -7245816, 15453652); wu(M, sp + -7245812, 15453656); wu(M, sp + -7245808, 15453660); wu(M, sp + -7245804, 15453664); wf(M, sp + -7245800, p10); wf(M, sp + -7245796, p9); wf(M, sp + -7245792, p8); wu(M, sp + -7245788, p7); wu(M, sp + -7245784, p6); wu(M, sp + -7245780, p5); wu(M, sp + -7245776, p4); wf(M, sp + -7245772, p3); wf(M, sp + -7245768, p2); wu(M, sp + -7245764, p1); NC(0x55d970, 14) end
  end
  local function C2()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8207832)
    f2 = rf(M, 8210284)
    f2 = f2 * rf(M, 8207836)
    f1 = f1 + f2
    f2 = rf(M, 8204276)
    f2 = f2 * rf(M, 8207840)
    f1 = f1 + f2
    wfd(8210284, f1)
    f1 = f1 * rf(M, 8213968)
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8207832)
    f3 = rf(M, 8210288)
    f3 = f3 * rf(M, 8207836)
    f2 = f2 + f3
    f3 = rf(M, 8204280)
    f3 = f3 * rf(M, 8207840)
    f2 = f2 + f3
    wfd(8210288, f2)
    f2 = f2 * rf(M, 8213980)
    f1 = f1 + f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8207832)
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8207836)
    f2 = f2 + f3
    f3 = rf(M, 8204284)
    f3 = f3 * rf(M, 8207840)
    f2 = f2 + f3
    wfd(8210280, f2)
    f2 = f2 * rf(M, 8213992)
    f1 = f1 + f2
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8207828)
    wfd(8210320, f2)
    f2 = f2 * rf(M, 8213968)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8207828)
    wfd(8210324, f3)
    f3 = f3 * rf(M, 8213980)
    f2 = f2 + f3
    f3 = rf(M, 8210308)
    f3 = f3 * rf(M, 8207828)
    wfd(8210316, f3)
    f3 = f3 * rf(M, 8213992)
    f2 = f2 + f3
    f1 = f1 + f2
    p1 = fd(f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8213964)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8213976)
    f1 = f1 + f2
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8213988)
    f1 = f1 + f2
    f2 = rf(M, 8210320)
    f2 = f2 * rf(M, 8213964)
    f3 = rf(M, 8210324)
    f3 = f3 * rf(M, 8213976)
    f2 = f2 + f3
    f3 = rf(M, 8210316)
    f3 = f3 * rf(M, 8213988)
    f2 = f2 + f3
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8210284)
    f1 = f1 * rf(M, 8213960)
    f2 = rf(M, 8210288)
    f2 = f2 * rf(M, 8213972)
    f1 = f1 + f2
    f2 = rf(M, 8210280)
    f2 = f2 * rf(M, 8213984)
    f1 = f1 + f2
    p3 = fd(f1)
    do local sp = NB(6); wu(M, sp + -7245816, 15453680); wu(M, sp + -7245812, 15453684); wu(M, sp + -7245808, 15453688); wf(M, sp + -7245804, p3); wf(M, sp + -7245800, p2); wf(M, sp + -7245796, p1); NC(0x55e160, 6) end
    f1 = rf(M, 8210320)
    f1 = f1 * rf(M, 8213960)
    f2 = rf(M, 8210324)
    f2 = f2 * rf(M, 8213972)
    f1 = f1 + f2
    f2 = rf(M, 8210316)
    f2 = f2 * rf(M, 8213984)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207856)
    wfd(8210316, f1)
    f1 = f1 + rf(M, 8214892)
    wfd(8214892, f1)
    f1 = rf(M, 8207860)
    f1 = f1 + rf(M, 8214896)
    wfd(8214896, f1)
    f1 = rf(M, 8207864)
    f1 = f1 + rf(M, 8214900)
    wfd(8214900, f1)
    f1 = rf(M, 8210456)
    f1 = f1 * rf(M, 8207864)
    f2 = rf(M, 8210312)
    f2 = f2 * rf(M, 8207860)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214904)
    wfd(8214904, f1)
    f1 = rf(M, 8210312)
    f1 = f1 * rf(M, 8207856)
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8207864)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214908)
    wfd(8214908, f1)
    f1 = rf(M, 8210492)
    f1 = f1 * rf(M, 8207860)
    f2 = rf(M, 8210456)
    f2 = f2 * rf(M, 8207856)
    f1 = f1 - f2
    f1 = f1 + rf(M, 8214912)
    wfd(8214912, f1)
    f1 = rf(M, 8210316)
    f1 = f1 * rf(M, 8213960)
    f2 = rf(M, 8207860)
    f2 = f2 * rf(M, 8213964)
    f1 = f1 + f2
    f2 = rf(M, 8207864)
    f2 = f2 * rf(M, 8213968)
    f1 = f1 + f2
    wfd(8211728, f1)
    f1 = rf(M, 8210316)
    f1 = f1 * rf(M, 8213972)
    f2 = rf(M, 8207860)
    f2 = f2 * rf(M, 8213976)
    f1 = f1 + f2
    f2 = rf(M, 8207864)
    f2 = f2 * rf(M, 8213980)
    f1 = f1 + f2
    wfd(8211732, f1)
    f1 = rf(M, 8210316)
    f1 = f1 * rf(M, 8213984)
    f2 = rf(M, 8207860)
    f2 = f2 * rf(M, 8213988)
    f1 = f1 + f2
    f2 = rf(M, 8207864)
    f2 = f2 * rf(M, 8213992)
    f1 = f1 + f2
    wfd(8211736, f1)
  end
  JIT[0xeb5531] = function() -- tire3
    C1()
    C2()
  end
end
do -- forces (3 chunks)
  local r_eax, r_ebx, r_ecx, r_edx, r_esi, r_edi
  local function C1()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    p1 = ru(M, 8211796)
    p2 = ru(M, 8211792)
    do local sp = NB(2); wu(M, sp + -7245816, p2); wu(M, sp + -7245812, p1); NC(0x55fc50, 2) end
    f1 = rf(M, 8214124)
    f1 = f1 * rf(M, 8204372)
    f2 = rf(M, 8214288)
    f2 = f2 * rf(M, 8204376)
    f1 = f1 + f2
    f2 = rf(M, 8214452)
    f2 = f2 * rf(M, 8204380)
    f1 = f1 + f2
    f2 = rf(M, 8213788)
    f2 = f2 * rf(M, 8204384)
    f1 = f1 + f2
    f2 = rf(M, 8213956)
    f2 = f2 * rf(M, 8204388)
    f1 = f1 + f2
    wfd(8210316, f1)
    f1 = f1 + rf(M, 8214452)
    r_eax = ru(M, 8214452)
    wu(M, 8210492, r_eax)
    wfd(8214452, f1)
    f1 = rf(M, 8214124)
    f1 = f1 * rf(M, 8204332)
    f2 = rf(M, 8214288)
    f2 = f2 * rf(M, 8204336)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8204340)
    f1 = f1 + f2
    f2 = rf(M, 8213788)
    f2 = f2 * rf(M, 8204344)
    f1 = f1 + f2
    f2 = rf(M, 8213956)
    f2 = f2 * rf(M, 8204348)
    f1 = f1 + f2
    wfd(8210456, f1)
    f1 = f1 + rf(M, 8214276)
    wfd(8214276, f1)
    f1 = rf(M, 8214124)
    f1 = f1 * rf(M, 8204352)
    f2 = rf(M, 8214288)
    f2 = f2 * rf(M, 8204356)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8204360)
    f1 = f1 + f2
    f2 = rf(M, 8213788)
    f2 = f2 * rf(M, 8204364)
    f1 = f1 + f2
    f2 = rf(M, 8213956)
    f2 = f2 * rf(M, 8204368)
    f1 = f1 + f2
    wfd(8210312, f1)
    f1 = f1 + rf(M, 8214440)
    wfd(8214440, f1)
    f1 = rf(M, 8210316)
    f1 = f1 + rf(M, 8214604)
    wfd(8214604, f1)
    f1 = rf(M, 8214124)
    f1 = f1 * rf(M, 8204392)
    f2 = rf(M, 8214288)
    f2 = f2 * rf(M, 8204396)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8204400)
    f1 = f1 + f2
    f2 = rf(M, 8213788)
    f2 = f2 * rf(M, 8204404)
    f1 = f1 + f2
    f2 = rf(M, 8213956)
    f2 = f2 * rf(M, 8204408)
    f1 = f1 + f2
    wfd(8210324, f1)
    f1 = f1 + rf(M, 8213948)
    wfd(8213948, f1)
    f1 = rf(M, 8214124)
    f1 = f1 * rf(M, 8204412)
    f2 = rf(M, 8214288)
    f2 = f2 * rf(M, 8204416)
    f1 = f1 + f2
    f2 = rf(M, 8210492)
    f2 = f2 * rf(M, 8204420)
    f1 = f1 + f2
    f2 = rf(M, 8213788)
    f2 = f2 * rf(M, 8204424)
    f1 = f1 + f2
    f2 = rf(M, 8213956)
    f2 = f2 * rf(M, 8204428)
    f1 = f1 + f2
    wfd(8210492, f1)
    f1 = f1 + rf(M, 8214116)
    wfd(8214116, f1)
    f1 = rf(M, 8210456)
    f1 = f1 * rf(M, 8218864)
    f1 = f1 * rf(M, 8218812)
    wfd(8210320, f1)
    p1 = ru(M, 8210320)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x560120, 1) end
    f1 = rf(M, 8210312)
    f1 = f1 * rf(M, 8218868)
    f1 = f1 * rf(M, 8218820)
    wfd(8210280, f1)
    p1 = ru(M, 8210280)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x560140, 1) end
    f1 = rf(M, 8210316)
    f1 = f1 * rf(M, 8218864)
    f1 = f1 * rf(M, 8218812)
    wfd(8210316, f1)
    p1 = ru(M, 8210316)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x5601a0, 1) end
    f1 = rf(M, 8210324)
    f1 = f1 * rf(M, 8218864)
    f1 = f1 * rf(M, 8218800)
    wfd(8210288, f1)
    p1 = ru(M, 8210288)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x560160, 1) end
    f1 = rf(M, 8210492)
    f1 = f1 * rf(M, 8218864)
    f1 = f1 * rf(M, 8218800)
    wfd(8210284, f1)
    p1 = ru(M, 8210284)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x560180, 1) end
    do local sp = NB(6); wu(M, sp + -7245816, 15453744); wu(M, sp + -7245812, 15453748); wu(M, sp + -7245808, 15453752); wu(M, sp + -7245804, 15453756); wu(M, sp + -7245800, 15453760); wu(M, sp + -7245796, 15453764); NC(0x560870, 6) end
    f1 = rf(M, 8218876)
    f1 = f1 * rf(M, 8212212)
    wfd(8214940, f1)
    f1 = rf(M, 8218880)
    f1 = f1 * rf(M, 8212216)
    wfd(8214944, f1)
    f1 = rf(M, 8218876)
    f1 = f1 * rf(M, 8212220)
    wfd(8214948, f1)
    f1 = rf(M, 8218884)
    f1 = f1 * rf(M, 8211864)
    wfd(8210308, f1)
    f1 = f1 * rf(M, 8212368)
    wfd(8214952, f1)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8212372)
    wfd(8214956, f1)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8212376)
    wfd(8214960, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8212728)
    wfd(8214964, f1)
    f1 = rf(M, 8218892)
    f1 = f1 * rf(M, 8212732)
    wfd(8214968, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8212736)
    wfd(8214972, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213248)
    wfd(8214976, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213252)
    wfd(8214980, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213256)
    wfd(8214984, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213816)
    f1 = f1 + rf(M, 8214868)
    wfd(8214868, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213824)
    f1 = f1 + rf(M, 8214876)
    wfd(8214876, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213984)
    f1 = f1 + rf(M, 8214892)
    wfd(8214892, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213992)
    f1 = f1 + rf(M, 8214900)
    wfd(8214900, f1)
    f1 = rf(M, 8218896)
    f1 = f1 * rf(M, 8213576)
    wfd(8214988, f1)
    f1 = rf(M, 8218900)
    f1 = f1 * rf(M, 8213580)
    wfd(8214992, f1)
    do local sp = NB(0); NC(0x561a80, 0) end
    p1 = ru(M, 8212048)
    p2 = ru(M, 8212044)
    p3 = ru(M, 8212040)
    f1 = rf(M, 8204432)
    f1 = rf(M, 8212028) - f1
    wfd(8210308, f1)
    f1 = f1 * rf(M, 8212100)
    f2 = rf(M, 8204436)
    f2 = rf(M, 8212032) - f2
    wfd(8210484, f2)
    f2 = f2 * rf(M, 8212112)
    f1 = f1 + f2
    f2 = rf(M, 8204440)
    f2 = rf(M, 8212036) - f2
    wfd(8210292, f2)
    f2 = f2 * rf(M, 8212124)
    f1 = f1 + f2
    p4 = fd(f1)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8212096)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212108)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8212120)
    f1 = f1 + f2
    p5 = fd(f1)
    f1 = rf(M, 8210308)
    f1 = f1 * rf(M, 8212092)
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212104)
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8212116)
    f1 = f1 + f2
    p6 = fd(f1)
    do local sp = NB(12); wu(M, sp + -7245816, 15453796); wu(M, sp + -7245812, 15453800); wu(M, sp + -7245808, 15453804); wu(M, sp + -7245804, 15453808); wu(M, sp + -7245800, 15453812); wu(M, sp + -7245796, 15453816); wf(M, sp + -7245792, p6); wf(M, sp + -7245788, p5); wf(M, sp + -7245784, p4); wu(M, sp + -7245780, p3); wu(M, sp + -7245776, p2); wu(M, sp + -7245772, p1); NC(0x561b70, 12) end
    f1 = rf(M, 8212028)
    f1 = f1 * rf(M, 8212100)
    f2 = rf(M, 8212032)
    f2 = f2 * rf(M, 8212112)
    f1 = f1 + f2
    f2 = rf(M, 8212036)
    f2 = f2 * rf(M, 8212124)
    f1 = f1 + f2
    p1 = fd(f1)
    f1 = rf(M, 8212028)
    f1 = f1 * rf(M, 8212096)
    f2 = rf(M, 8212032)
    f2 = f2 * rf(M, 8212108)
    f1 = f1 + f2
    f2 = rf(M, 8212036)
    f2 = f2 * rf(M, 8212120)
    f1 = f1 + f2
    p2 = fd(f1)
    f1 = rf(M, 8212028)
    f1 = f1 * rf(M, 8212092)
    f2 = rf(M, 8212032)
    f2 = f2 * rf(M, 8212104)
    f1 = f1 + f2
    f2 = rf(M, 8212036)
    f2 = f2 * rf(M, 8212116)
    f1 = f1 + f2
    p3 = fd(f1)
    do local sp = NB(9); wu(M, sp + -7245816, 15453832); wu(M, sp + -7245812, 15453836); wu(M, sp + -7245808, 15453840); wu(M, sp + -7245804, 15453844); wu(M, sp + -7245800, 15453848); wu(M, sp + -7245796, 15453852); wf(M, sp + -7245792, p3); wf(M, sp + -7245788, p2); wf(M, sp + -7245784, p1); NC(0x561e50, 9) end
    f1 = rf(M, 8213024)
    f1 = rf(M, 8212504) - f1
    f1 = f1 - rf(M, 8204188)
    f1 = f1 * rf(M, 8204132)
    wfd(8210292, f1)
    p1 = ru(M, 8212504)
    f1 = LKU(7659776, p1)
    p1 = ru(M, 8212500)
    f2 = LKU(7660176, p1)
    f1 = f1 + f2
    wfd(8210484, f1)
    f1 = rf(M, 8210484)
    f1 = f1 + rf(M, 8210292)
    wfd(8215000, f1)
    p1 = ru(M, 8213024)
    f1 = LKU(7659872, p1)
    p1 = ru(M, 8213020)
    f2 = LKU(7660472, p1)
    f1 = f1 + f2
    wfd(8210308, f1)
    f1 = rf(M, 8210292)
    f1 = -f1
    f1 = f1 + rf(M, 8210308)
    wfd(8215004, f1)
    f1 = rf(M, 8218904)
    f1 = f1 * rf(M, 8213612)
    wfd(8210432, f1)
    f1 = f1 + rf(M, 8213548)
    p1 = fd(f1)
    f1 = LKF(7659968, p1)
    f2 = rf(M, 8218908)
    f2 = f2 * rf(M, 8213544)
    wfd(8210328, f2)
    f2 = f2 + rf(M, 8213540)
    p1 = fd(f2)
    f2 = LKF(7660768, p1)
    f1 = f1 + f2
    wfd(8210520, f1)
    f1 = rf(M, 8210432)
    f1 = rf(M, 8213548) - f1
    f1 = f1 - rf(M, 8204184)
    p1 = fd(f1)
    f1 = LKF(7660064, p1)
    f2 = rf(M, 8210328)
    f2 = rf(M, 8213540) - f2
    p1 = fd(f2)
    f2 = LKF(7661064, p1)
    f1 = f1 + f2
    wfd(8210328, f1)
    f1 = f1 + rf(M, 8210520)
    wfd(8210432, f1)
  end
  local function C2()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8218896)
    f1 = f1 * rf(M, 8213584)
    f1 = f1 + rf(M, 8210432)
    wfd(8214996, f1)
    f1 = rf(M, 8210456)
    f1 = f1 + rf(M, 8214124)
    wfd(8214124, f1)
    p1 = ru(M, 8214124)
    p2 = ru(M, 8211784)
    do local sp = NB(3); wu(M, sp + -7245816, 15453904); wu(M, sp + -7245812, p2); wu(M, sp + -7245808, p1); NC(0x560dd0, 3) end
    f1 = rf(M, 8210312)
    f1 = f1 + rf(M, 8214288)
    wfd(8214288, f1)
    f1 = f1 * rf(M, 8218912)
    wfd(8210516, f1)
    f1 = rf(M, 8214124)
    f1 = f1 * rf(M, 8218812)
    f2 = rf(M, 8210516)
    f2 = f2 + rf(M, 8208080)
    f2 = f2 * rf(M, 8218136)
    f1 = f1 + f2
    f2 = rf(M, 8214288)
    f2 = f2 * rf(M, 8218820)
    f1 = f1 + f2
    f1 = f1 * rf(M, 8218704)
    f1 = rf(M, 8214288) - f1
    f1 = f1 * rf(M, 8218820)
    f1 = f1 * rf(M, 8218868)
    f1 = f1 + rf(M, 8210516)
    p1 = fd(f1)
    f1 = rf(M, 8211792)
    f1 = f1 * rf(M, 8218916)
    p2 = fd(f1)
    do local sp = NB(3); wu(M, sp + -7245816, 15453908); wf(M, sp + -7245812, p2); wf(M, sp + -7245808, p1); NC(0x561040, 3) end
    f1 = rf(M, 8212868)
    f1 = f1 * rf(M, 8218788)
    f1 = f1 * rf(M, 8218868)
    f1 = f1 + rf(M, 8214836)
    p1 = fd(f1)
    f1 = rf(M, 8204196)
    f1 = f1 * rf(M, 8211788)
    f1 = f1 + rf(M, 8218920)
    f2 = rf(M, 8212868)
    f2 = f2 * f2
    f2 = f2 * rf(M, 8218924)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204316)
    p2 = fd(f1)
    do local sp = NB(3); wu(M, sp + -7245816, 15453920); wf(M, sp + -7245812, p2); wf(M, sp + -7245808, p1); NC(0x561040, 3) end
    f1 = rf(M, 8208096)
    f1 = f1 + rf(M, 8214836)
    wfd(8214836, f1)
    f1 = rf(M, 8208096)
    f1 = f1 * rf(M, 8218276)
    wfd(8210312, f1)
    f1 = -f1
    wfd(8215020, f1)
    f1 = rf(M, 8208096)
    f1 = f1 * rf(M, 8218280)
    f1 = -f1
    wfd(8215024, f1)
    p1 = ru(M, 8210312)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x55e450, 1) end
    f1 = rf(M, 8213388)
    f1 = f1 * rf(M, 8218788)
    f1 = f1 * rf(M, 8218868)
    f1 = f1 + rf(M, 8214860)
    p1 = fd(f1)
    f1 = rf(M, 8204200)
    f1 = f1 * rf(M, 8211788)
    f1 = f1 + rf(M, 8218920)
    f2 = rf(M, 8213388)
    f2 = f2 * f2
    f2 = f2 * rf(M, 8218928)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204320)
    p2 = fd(f1)
    do local sp = NB(3); wu(M, sp + -7245816, 15453932); wf(M, sp + -7245812, p2); wf(M, sp + -7245808, p1); NC(0x561040, 3) end
    f1 = rf(M, 8208108)
    f1 = f1 + rf(M, 8214860)
    wfd(8214860, f1)
    f1 = rf(M, 8208108)
    f1 = f1 * rf(M, 8218276)
    wfd(8210312, f1)
    f1 = -f1
    wfd(8215028, f1)
    f1 = rf(M, 8208108)
    f1 = f1 * rf(M, 8218336)
    f1 = -f1
    wfd(8215032, f1)
    p1 = ru(M, 8210312)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x55e460, 1) end
    f1 = rf(M, 8210324)
    f1 = f1 + rf(M, 8213788)
    wfd(8213788, f1)
    f1 = f1 * rf(M, 8218800)
    f1 = f1 * rf(M, 8218868)
    f1 = f1 + rf(M, 8214884)
    p1 = fd(f1)
    f1 = rf(M, 8204204)
    f1 = f1 * rf(M, 8211788)
    f1 = f1 + rf(M, 8218920)
    f2 = rf(M, 8213788)
    f2 = f2 * f2
    f2 = f2 * rf(M, 8218924)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204324)
    p2 = fd(f1)
    do local sp = NB(3); wu(M, sp + -7245816, 15453948); wf(M, sp + -7245812, p2); wf(M, sp + -7245808, p1); NC(0x561040, 3) end
    f1 = rf(M, 8208124)
    f1 = f1 * rf(M, 8218384)
    wfd(8210312, f1)
    p1 = ru(M, 8210312)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x55e470, 1) end
    f1 = rf(M, 8210492)
    f1 = f1 + rf(M, 8213956)
    wfd(8213956, f1)
    f1 = f1 * rf(M, 8218800)
    f1 = f1 * rf(M, 8218868)
    f1 = f1 + rf(M, 8214908)
    p1 = fd(f1)
    f1 = rf(M, 8204208)
    f1 = f1 * rf(M, 8211788)
    f1 = f1 + rf(M, 8218920)
    f2 = rf(M, 8213956)
    f2 = f2 * f2
    f2 = f2 * rf(M, 8218924)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8204328)
    p2 = fd(f1)
    do local sp = NB(3); wu(M, sp + -7245816, 15453968); wf(M, sp + -7245812, p2); wf(M, sp + -7245808, p1); NC(0x561040, 3) end
    f1 = rf(M, 8210520)
    f1 = f1 * rf(M, 8218904)
    f2 = rf(M, 8210328)
    f2 = f2 * rf(M, 8218904)
    f1 = f1 - f2
    wfd(8210328, f1)
    f1 = rf(M, 8208124)
    f1 = f1 * rf(M, 8218396)
    f1 = rf(M, 8210328) - f1
    f2 = rf(M, 8208144)
    f2 = f2 * rf(M, 8218408)
    f1 = f1 - f2
    wfd(8215008, f1)
    f1 = rf(M, 8208144)
    f1 = f1 * rf(M, 8218384)
    wfd(8210520, f1)
    f1 = rf(M, 8210312)
    f1 = -f1
    f1 = f1 - rf(M, 8210520)
    wfd(8215036, f1)
    p1 = ru(M, 8210520)
    do local sp = NB(1); wu(M, sp + -7245816, p1); NC(0x55e480, 1) end
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213820)
    f1 = f1 + rf(M, 8214872)
    wfd(8214872, f1)
    f1 = rf(M, 8218888)
    f1 = f1 * rf(M, 8213988)
    f1 = f1 + rf(M, 8214896)
    wfd(8214896, f1)
    f1 = f1 + rf(M, 8214872)
    p1 = fd(f1)
    p2 = ru(M, 8211796)
    p3 = ru(M, 8211792)
    f1 = rf(M, 8208084)
    f1 = rf(M, 8208080) - f1
    wfd(8215012, f1)
    p4 = ru(M, 8215012)
    f1 = rf(M, 8210516)
    f1 = f1 + rf(M, 8208084)
    wfd(8215016, f1)
    p5 = ru(M, 8215016)
    do local sp = NB(6); wu(M, sp + -7245816, 15453984); wu(M, sp + -7245812, p5); wu(M, sp + -7245808, p4); wu(M, sp + -7245804, p3); wu(M, sp + -7245800, p2); wf(M, sp + -7245796, p1); NC(0x5614b0, 6) end
    f1 = rf(M, 8208124)
    f1 = f1 + rf(M, 8214884)
    wfd(8210520, f1)
    f1 = rf(M, 8213956)
    f1 = f1 * rf(M, 8218800)
    f2 = rf(M, 8208144)
    f2 = f2 + rf(M, 8214908)
    wfd(8210312, f2)
    f2 = f2 + rf(M, 8210520)
    f2 = f2 * rf(M, 8218136)
    f1 = f1 + f2
    f2 = rf(M, 8213788)
    f2 = f2 * rf(M, 8218800)
    f1 = f1 + f2
    f1 = f1 * rf(M, 8218932)
    f1 = rf(M, 8213788) - f1
    f1 = f1 * rf(M, 8218800)
    f1 = f1 * rf(M, 8218868)
    f1 = f1 + rf(M, 8210520)
    p1 = fd(f1)
    p2 = ru(M, 8208160)
    do local sp = NB(3); wu(M, sp + -7245816, 15453988); wu(M, sp + -7245812, p2); wf(M, sp + -7245808, p1); NC(0x561040, 3) end
    f1 = rf(M, 8210520)
    f1 = f1 + rf(M, 8208164)
    wfd(8214884, f1)
    f1 = rf(M, 8210312)
    f1 = f1 - rf(M, 8208164)
    wfd(8214908, f1)
    f1 = rf(M, 8207972)
    f1 = f1 * rf(M, 8212092)
    f2 = rf(M, 8207976)
    f2 = f2 * rf(M, 8212096)
    f1 = f1 + f2
    f2 = rf(M, 8207980)
    f2 = f2 * rf(M, 8212100)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207920)
    f2 = rf(M, 8208008)
    f2 = f2 * rf(M, 8212092)
    f3 = rf(M, 8208012)
    f3 = f3 * rf(M, 8212096)
    f2 = f2 + f3
    f3 = rf(M, 8208016)
    f3 = f3 * rf(M, 8212100)
    f2 = f2 + f3
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8212620)
    f1 = f1 - f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213140)
    f1 = f1 + f2
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212620)
    f1 = f1 - f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213140)
    f1 = f1 - f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213688)
    f1 = f1 - f2
    p1 = ru(M, 8214628)
    f2 = LKU(7298016, p1)
    p1 = ru(M, 8214616)
    f3 = LKU(7298072, p1)
    f2 = f2 + f3
    wfd(8215040, f2)
    f2 = f2 * rf(M, 8214736)
    p1 = ru(M, 8214632)
    f3 = LKU(7298016, p1)
    p1 = ru(M, 8214620)
    f4 = LKU(7298072, p1)
    f3 = f3 + f4
    wfd(8215044, f3)
    f3 = f3 * rf(M, 8214740)
    f2 = f2 + f3
    p1 = ru(M, 8214636)
    f3 = LKU(7298128, p1)
    p1 = ru(M, 8214624)
    f4 = LKU(7298184, p1)
    f3 = f3 + f4
    wfd(8215048, f3)
    f3 = f3 * rf(M, 8214748)
    f2 = f2 + f3
    f1 = f1 - f2
    wfd(8214924, f1)
    f1 = rf(M, 8207972)
    f1 = f1 * rf(M, 8212104)
    f2 = rf(M, 8207976)
    f2 = f2 * rf(M, 8212108)
    f1 = f1 + f2
    f2 = rf(M, 8207980)
    f2 = f2 * rf(M, 8212112)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207924)
    f2 = rf(M, 8208008)
    f2 = f2 * rf(M, 8212104)
    f3 = rf(M, 8208012)
    f3 = f3 * rf(M, 8212108)
    f2 = f2 + f3
    f3 = rf(M, 8208016)
    f3 = f3 * rf(M, 8212112)
    f2 = f2 + f3
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8212644)
    f1 = f1 - f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213164)
    f1 = f1 + f2
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212644)
    f1 = f1 - f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213164)
    f1 = f1 - f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213720)
    f1 = f1 - f2
    f2 = rf(M, 8215040)
    f2 = f2 * rf(M, 8214756)
    f3 = rf(M, 8215044)
    f3 = f3 * rf(M, 8214764)
    f2 = f2 + f3
    f3 = rf(M, 8215048)
    f3 = f3 * rf(M, 8214768)
    f2 = f2 + f3
    f1 = f1 - f2
    wfd(8214928, f1)
  end
  local function C3()
    local f1, f2, f3, f4, f5, f6, f7, f8, q
    local p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60, p61, p62, p63
    f1 = rf(M, 8207932)
    f1 = f1 * rf(M, 8212136)
    f2 = rf(M, 8207936)
    f2 = f2 * rf(M, 8212148)
    f1 = f1 + f2
    f2 = rf(M, 8207940)
    f2 = f2 * rf(M, 8212160)
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207992)
    f1 = f1 + rf(M, 8208028)
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8212672)
    f1 = f1 - f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213192)
    f1 = f1 + f2
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212672)
    f1 = f1 - f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213192)
    f1 = f1 - f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213756)
    f3 = rf(M, 8210328)
    f3 = f3 * rf(M, 8218352)
    f2 = f2 + f3
    f1 = f1 - f2
    f2 = rf(M, 8215040)
    f2 = f2 * rf(M, 8214780)
    f3 = rf(M, 8215044)
    f3 = f3 * rf(M, 8214788)
    f2 = f2 + f3
    f1 = f1 - f2
    wfd(8214936, f1)
    f1 = rf(M, 8212048)
    f1 = -f1
    f1 = f1 * rf(M, 8212152)
    f2 = rf(M, 8212040)
    f2 = f2 * rf(M, 8212160)
    f1 = f1 + f2
    wfd(8210520, f1)
    f1 = rf(M, 8212036) - f1
    p1 = fd(f1)
    f1 = rf(M, 8210520)
    f1 = f1 + rf(M, 8212036)
    p2 = fd(f1)
    f1 = rf(M, 8212156)
    f1 = rf(M, 8212060) - f1
    p3 = fd(f1)
    f1 = rf(M, 8212060)
    f1 = f1 + rf(M, 8212156)
    p4 = fd(f1)
    do local sp = NB(6); wu(M, sp + -7245816, 15454012); wu(M, sp + -7245812, 15454016); wf(M, sp + -7245808, p4); wf(M, sp + -7245804, p3); wf(M, sp + -7245800, p2); wf(M, sp + -7245796, p1); NC(0x5618d0, 6) end
    f1 = rf(M, 8218872)
    f1 = f1 + rf(M, 8207928)
    f2 = rf(M, 8207972)
    f2 = f2 * rf(M, 8212116)
    f3 = rf(M, 8207976)
    f3 = f3 * rf(M, 8212120)
    f2 = f2 + f3
    f3 = rf(M, 8207980)
    f3 = f3 * rf(M, 8212124)
    f2 = f2 + f3
    f1 = f1 + f2
    f2 = rf(M, 8208008)
    f2 = f2 * rf(M, 8212116)
    f3 = rf(M, 8208012)
    f3 = f3 * rf(M, 8212120)
    f2 = f2 + f3
    f3 = rf(M, 8208016)
    f3 = f3 * rf(M, 8212124)
    f2 = f2 + f3
    f1 = f1 + f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8212668)
    f1 = f1 - f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213188)
    f1 = f1 + f2
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212668)
    f1 = f1 - f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213188)
    f1 = f1 - f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213752)
    f1 = f1 - f2
    f2 = rf(M, 8215040)
    f2 = f2 * rf(M, 8214776)
    f3 = rf(M, 8215044)
    f3 = f3 * rf(M, 8214784)
    f2 = f2 + f3
    f3 = rf(M, 8215048)
    f3 = f3 * rf(M, 8214792)
    f2 = f2 + f3
    f1 = f1 - f2
    f2 = rf(M, 8208192)
    f2 = f2 + rf(M, 8208188)
    f1 = f1 + f2
    wfd(8214932, f1)
    f1 = rf(M, 8208192)
    f1 = rf(M, 8208188) - f1
    wfd(8210520, f1)
    f1 = rf(M, 8210320)
    f1 = -f1
    f1 = f1 - rf(M, 8210280)
    f1 = f1 - rf(M, 8210316)
    f2 = rf(M, 8207932)
    f2 = f2 * rf(M, 8212128)
    f3 = rf(M, 8207936)
    f3 = f3 * rf(M, 8212140)
    f2 = f2 + f3
    f3 = rf(M, 8207940)
    f3 = f3 * rf(M, 8212152)
    f2 = f2 + f3
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207984)
    f1 = f1 + rf(M, 8208020)
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8212624)
    f1 = f1 - f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213144)
    f1 = f1 + f2
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212624)
    f1 = f1 - f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213144)
    f1 = f1 - f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213692)
    f3 = rf(M, 8210328)
    f3 = f3 * rf(M, 8218348)
    f2 = f2 + f3
    f1 = f1 - f2
    f2 = rf(M, 8208080)
    f2 = f2 * rf(M, 8218412)
    f1 = f1 - f2
    f2 = rf(M, 8210516)
    f2 = f2 * rf(M, 8218412)
    f1 = f1 - f2
    f2 = rf(M, 8215044)
    f2 = f2 * rf(M, 8214744)
    f3 = rf(M, 8215048)
    f3 = f3 * rf(M, 8214752)
    f2 = f2 + f3
    f1 = f1 - f2
    f1 = f1 + rf(M, 8210520)
    wfd(8214916, f1)
    f1 = rf(M, 8210288)
    f1 = -f1
    f1 = f1 - rf(M, 8210284)
    f2 = rf(M, 8207932)
    f2 = f2 * rf(M, 8212132)
    f3 = rf(M, 8207936)
    f3 = f3 * rf(M, 8212144)
    f2 = f2 + f3
    f3 = rf(M, 8207940)
    f3 = f3 * rf(M, 8212156)
    f2 = f2 + f3
    f1 = f1 + f2
    f1 = f1 + rf(M, 8207988)
    f1 = f1 + rf(M, 8208024)
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8212648)
    f1 = f1 - f2
    f2 = rf(M, 8210292)
    f2 = f2 * rf(M, 8213168)
    f1 = f1 + f2
    f2 = rf(M, 8210484)
    f2 = f2 * rf(M, 8212648)
    f1 = f1 - f2
    f2 = rf(M, 8210308)
    f2 = f2 * rf(M, 8213168)
    f1 = f1 - f2
    f2 = rf(M, 8210432)
    f2 = f2 * rf(M, 8213724)
    f1 = f1 - f2
    f2 = rf(M, 8208080)
    f2 = f2 * rf(M, 8218416)
    f1 = f1 - f2
    f2 = rf(M, 8210516)
    f2 = f2 * rf(M, 8218416)
    f1 = f1 - f2
    f2 = rf(M, 8215040)
    f2 = f2 * rf(M, 8214760)
    f3 = rf(M, 8215048)
    f3 = f3 * rf(M, 8214772)
    f2 = f2 + f3
    f1 = f1 - f2
    f2 = rf(M, 8210520)
    f2 = abs(f2)
    f2 = f2 * rf(M, 8218144)
    f1 = f1 + f2
    wfd(8214920, f1)
    do local sp = NB(0); NC(0x560300, 0) end
  end
  JIT[0xeb5af7] = function() -- forces
    C1()
    C2()
    C3()
  end
end
end
