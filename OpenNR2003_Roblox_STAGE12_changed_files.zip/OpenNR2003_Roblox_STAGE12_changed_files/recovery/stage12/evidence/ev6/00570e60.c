/* NR2003.exe @ 00570e60 FUN_00570e60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00570e60(undefined4 param_1)

{
  char cVar1;
  
  cVar1 = FUN_005f8da0(&DAT_00c69034);
  if (cVar1 != '\0') {
    _DAT_00c6b460 = param_1;
    FUN_005f8e20(&DAT_00c69034);
    return 1;
  }
  return 0;
}

