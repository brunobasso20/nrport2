# Roadmap status — após Stage 12

| Stage | Status | O que é verdade agora |
|---|---|---|
| 1. Grafo multibody completo | **DONE** | 16 componentes / 45 estados; no carro em Play via núcleo original gerado. |
| 2. Avaliação de derivadas | **DONE** | Callbacks originais (predictor/solve/corrector/commit) traduzidas e ativas. |
| 3. Restrições e propagação de forças | **DONE** | Solve 005b3180+0055e410 e forças 005b3990 originais ativas. |
| 4. Integrador original | **DONE** | 288 Hz, predictor→forças→corrector→forças→commit na ordem de 005b2190. |
| 5. Substituir integração Roblox do chassi | **DONE + STUDIO VALIDATED** | Modo `NR2003_CORE` preservado intacto como fallback. |
| 6. Suspensão / massas não suspensas / eixo traseiro | **DONE + STUDIO VALIDATED** | Inalterado; agora configurável pelo setup (Stage 10). |
| 7. Drivetrain completo | **DONE + STUDIO VALIDATED** | Inalterado; marchas/diferencial do setup pelo build original (Stage 10). |
| 8. Modelo de freio completo | **DONE + STUDIO VALIDATED** (usuário, antes do Stage 9) | Inalterado; células re-ligadas após um rebuild (Stage 10). |
| 9. Aero completo | **DONE (automático) — pendente validação manual no Studio** | Aero original (`00561a80`/`00561b70`/`00410280`, curvas, estol, dano) agora com entradas reais: sessão `005a3c00` (ρ, vento), fatores por quadro `005637e0`, vácuo `005afd80` (interface; sem outros carros na bancada), fita/aerofólio. Validado contra o original executado (vetores bit a bit, 44 snapshots, 17 cenários). Clima dinâmico `005a4cc0` mapeado e não portado. |
| 10. Setup → runtime | **DONE (automático) — pendente validação manual no Studio** | Caminho original completo recuperado (184 itens `c05150`, 29 conversores, garagem, .sto, `00559360` → rebuild, `00425ad0`, `0055e9b0`). Garagem portada bit a bit; build original do carro erguido para Luau (388 funções) com as decisões do emissor por tabela (estrutura natural exata / genérica); padrão = imagem entregue bit a bit. Validado contra o original: 184 builds de item, 9 setups com corrida de 8 s. Pit stop (`005601c0`/`00550f10`) mapeado, não portado. |
| 11. Térmica/desgaste/dano/combustível | **DONE (automático) — pendente validação manual no Studio** | Fim de quadro ORIGINAL `00554520` + dano de colisão `00549c40` erguidos do x86 (motor, combustível → massa/inércia, pneus 3 zonas/pressão/desgaste/estouro, freios, falhas aleatórias, dano de colisão com árvore de zonas `00433610`); eventos: registro de colisão `0054a760`, troca de pneus `00550f10`, carro na pista `00550a50`; opções de corrida (dano, consumo). Validado contra o original: início de sessão e snapshots bit a bit, reinícios de estado completo, corridas em malha fechada no envelope dos gêmeos do original, determinismo. Fronteira do host documentada (objeto de colisão do sistema de pista sem deformação, série do roster PROVISIONAL). |
| 12. Cadeia de direção completa | **DONE (automático) — pendente validação manual no Studio** | Cadeia ORIGINAL portada à mão do x86: dispositivos (controles 7/8, eixo separado pelo sinal), `00552d00` (taxa + seno), `00552720` (sensibilidade pela linearidade), cauda de `00551e80` (expoente de linearidade com eixos analógicos, × π, ÷ relação `00554fb0` = item 0x30 com override 7:1 até 8,94 m/s), rampa por tick + toe → cubos prescritos; setters das opções; volante do cockpit `005662d0`. Sem Ackermann/bump steer/taxa de esterço (geometria original do multicorpo). Validado contra o original: funções bit a bit, snapshots de início de quadro bit a bit, reinícios de estado completo, malha fechada no envelope de 14 gêmeos (horizonte documentado `notdriven`), 5 mutações detectadas. Não portados (recusados): assistência de direção (linha de corrida da pista) e modo arcade (bit 25; troca o chassi no build). |
| 13. Torque de direção / FFB | **NOT DONE** | Interface mapeada no Stage 12 (`STAGE12_RECOVERY.md` §8, `NEXT_PROMPT_STAGE13.txt`): o FFB original não lê células da cadeia de direção; usa estatísticas dos pneus dianteiros (`00554e70` → `00554d30`) e o item 0x30; nada volta para a física. |
| 14. Predição cliente + reconciliação | **NOT DONE** | Servidor autoritativo + interpolação de apresentação (estágio 5). Vácuo multi-carro depende deste estágio (ordem de corrida e posição na pista dos outros carros). |
| 15. Replay determinístico vs NR2003 | **PARCIAL** | Trajetórias do carro completo comparadas contra o código original executado (Unicorn), agora com aero; captura do jogo real ainda não. |

## Carro de referência

NR2003 NASCAR/Cup (série 0, chassis type 2 "spdway", spec `0x7238e0`) com setup padrão do próprio jogo e sessão padrão
das opções de corrida (70 °F, sem vento, condição 0, dia → ρ 1,0812 kg/m³). `TestTune` continua apenas para
`NR2003_CORE`/`ROBLOX_ADAPTER`; `CupTune` só posiciona peças e consultas do host.
